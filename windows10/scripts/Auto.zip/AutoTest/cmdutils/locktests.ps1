$nativeDef = @'
using System;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Microsoft.Win32.SafeHandles;

public static class NTSTATUS
{
    public const uint STATUS_SUCCESS = 0;
    public const uint STATUS_BUFFER_OVERFLOW = 0x80000005;
    public const uint STATUS_INFO_LENGTH_MISMATCH = 0xC0000004;
}

[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct SECURITY_ATTRIBUTES
{
   public Int32 cb;
   public IntPtr securityDescriptor;
   public bool inheritHandle;
};

public static class ProcessAccessRights
{
    public const uint PROCESS_DUP_HANDLE = 0x0040;
    public const uint PROCESS_QUERY_INFORMATION = 0x400;
    public const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
}

[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct STARTUPINFO
{
   public Int32 cb;
   public string lpReserved;
   public string lpDesktop;
   public string lpTitle;
   public Int32 dwX;
   public Int32 dwY;
   public Int32 dwXSize;
   public Int32 dwYSize;
   public Int32 dwXCountChars;
   public Int32 dwYCountChars;
   public Int32 dwFillAttribute;
   public Int32 dwFlags;
   public Int16 wShowWindow;
   public Int16 cbReserved2;
   public IntPtr lpReserved2;
   public IntPtr hStdInput;
   public IntPtr hStdOutput;
   public IntPtr hStdError;
};

[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct PROCESS_INFORMATION
{
   public IntPtr hProcess;
   public IntPtr hThread;
   public int dwProcessId;
   public int dwThreadId;
};


public static class AccessRights
{
    public const uint GENERIC_READ = 0x80000000;
    public const uint GENERIC_WRITE = 0x40000000;
    public const uint GENERIC_EXECUTE = 0x20000000;
    public const uint GENERIC_ALL = 0x10000000;
}

public static class ShareMode
{
    public const uint FILE_SHARE_READ = 0x00000001;
    public const uint FILE_SHARE_WRITE = 0x00000002;
    public const uint FILE_SHARE_DELETE = 0x00000004;
}

public enum PROCESSINFOCLASS : uint
{
    ProcessBasicInformation = 0,
    ProcessDebugPort = 7,
    ProcessWow64Information = 26,
    ProcessImageFileName = 27,
    ProcessBreakOnTermination = 29,
    ProcessHandleInformation = 51
};

/// <summary>
/// Derived from fileapi.h and wdm.h
/// </summary>
public static class CreateDisposition
{
    // It seems CBFS will give us the win32 disposition in all cases except for
    // FILE_SUPERSEDE where there is no win32 equivalent.

    // ** Native disposition values from wdm.h - NtCreateFile 

    /// <summary>
    /// If the file already exists, replace it with the given file. If it does not, create the given file.
    /// </summary>
    public const int FILE_SUPERSEDE = 0;

    // ** Win32 disposition values from fileapi.h - CreateFile 

    /// <summary>
    /// Creates a new file, only if it does not already exist.
    /// If the specified file exists, the function fails and the last-error code is set to ERROR_FILE_EXISTS (80).
    /// If the specified file does not exist and is a valid path to a writable location, a new file is created.
    /// </summary>
    public const int CREATE_NEW = 1;

    /// <summary>
    /// Creates a new file, always.
    /// If the specified file exists and is writable, the function overwrites the file, the function succeeds, 
    /// and last-error code is set to ERROR_ALREADY_EXISTS(183).
    /// If the specified file does not exist and is a valid path, a new file is created, the function succeeds, 
    /// and the last-error code is set to zero.
    /// </summary>
    public const int CREATE_ALWAYS = 2;

    /// <summary>
    /// Opens a file or device, only if it exists.
    /// If the specified file or device does not exist, the function fails and the last-error code is set to 
    /// ERROR_FILE_NOT_FOUND(2).
    /// </summary>
    public const int OPEN_EXISTING = 3;

    /// <summary>
    /// Opens a file, always.
    /// If the specified file exists, the function succeeds and the last-error code is set to ERROR_ALREADY_EXISTS (183).
    /// If the specified file does not exist and is a valid path to a writable location, the function creates a 
    /// file and the last-error code is set to zero.
    /// </summary>
    public const int OPEN_ALWAYS = 4;

    /// <summary>
    /// Opens a file and truncates it so that its size is zero bytes, only if it exists.
    /// If the specified file does not exist, the function fails and the last-error code is set to ERROR_FILE_NOT_FOUND(2).
    /// The calling process must open the file with the GENERIC_WRITE bit set as part of the dwDesiredAccess parameter.
    /// </summary>
    public const int TRUNCATE_EXISTING = 5;
}

[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct IO_STATUS_BLOCK 
{
   public UInt32 status;
   public IntPtr information;  
};

/// <summary>
/// Returned by NtQueryInformationProcess / ProcessHandleInformation to hold handle information for 
/// a process. This structure appears to be undocumented by Microsoft (I was unable to find in any header), but 
/// was found in several open source projects such as Cygwin, systeminformer and process hacker.
/// </summary>
[StructLayoutAttribute(LayoutKind.Sequential)]
public struct PROCESS_HANDLE_SNAPSHOT_INFORMATION
{
    // IntPtr because it is a ULONG_PTR which is different between 32/64 bit
    public IntPtr NumberOfHandles;
    IntPtr Reserved;
    public PROCESS_HANDLE_TABLE_ENTRY_INFO FirstHandleEntry;
}

[StructLayoutAttribute(LayoutKind.Sequential)]
public struct PROCESS_HANDLE_TABLE_ENTRY_INFO
{
    public IntPtr HandleValue;
    public IntPtr HandleCount;
    public IntPtr PointerCount;
    public uint GrantedAccess;
    public uint ObjectTypeIndex;
    public uint HandleAttributes;
    public uint Reserved;
}

/// <summary>
/// Object type information used by NtQueryObject
/// (winternl.h)
/// </summary>
[StructLayout(LayoutKind.Sequential)]
unsafe public struct PUBLIC_OBJECT_TYPE_INFORMATION
{
    public UNICODE_STRING TypeName;
    public fixed uint Reserved[22];    // reserved for internal use
}

// From https://www.pinvoke.net/default.aspx/Structures/UNICODE_STRING.html
[StructLayout(LayoutKind.Sequential)]
public struct UNICODE_STRING : IDisposable
{
    public ushort Length;
    public ushort MaximumLength;
    private IntPtr buffer;

    public UNICODE_STRING(string s)
    {
        Length = (ushort)(s.Length * 2);
        MaximumLength = (ushort)(Length + 2);
        buffer = Marshal.StringToHGlobalUni(s);
    }

    public void Dispose()
    {
        Marshal.FreeHGlobal(buffer);
        buffer = IntPtr.Zero;
    }

    public override string ToString()
    {
        return Marshal.PtrToStringUni(buffer);
    }
}

public enum OBJECT_INFORMATION_CLASS
{
    ObjectBasicInformation = 0,
    ObjectTypeInformation = 2,
}

// Locally Unique Identifier
// (winnt.h)
[StructLayout(LayoutKind.Sequential)]
public struct LUID
{
    uint LowPart;
    int HighPart;
}

[StructLayout(LayoutKind.Sequential)]
public struct LUID_AND_ATTRIBUTES
{
    public LUID Luid;
    public uint Attributes;
}

[StructLayout(LayoutKind.Sequential)]
public struct TOKEN_PRIVILEGES
{
    public uint PrivilegeCount;
    public LUID_AND_ATTRIBUTES PrivilegesFirstEntry;
}

public static class TokenAccessRights
{
    public const uint TOKEN_ASSIGN_PRIMARY = 0x0001;
    public const uint TOKEN_DUPLICATE = 0x0002;
    public const uint TOKEN_IMPERSONATE = 0x0004;
    public const uint TOKEN_QUERY = 0x0008;
    public const uint TOKEN_QUERY_SOURCE = 0x0010;
    public const uint TOKEN_ADJUST_PRIVILEGES = 0x0020;
    public const uint TOKEN_ADJUST_GROUPS = 0x0040;
    public const uint TOKEN_ADJUST_DEFAULT = 0x0080;
    public const uint TOKEN_ADJUST_SESSIONID = 0x0100;
}

public static class PrivilegeAccess
{
    public const uint SE_PRIVILEGE_ENABLED_BY_DEFAULT = 0x00000001;
    public const uint SE_PRIVILEGE_ENABLED = 0x00000002;
    public const uint SE_PRIVILEGE_REMOVED = 0X00000004;
    public const uint SE_PRIVILEGE_USED_FOR_ACCESS = 0x80000000;
}


public static class Native
{
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool CreateProcessW(
        IntPtr applicationName,
        string commandLine, 
        IntPtr processSecurityAttributes, 
        IntPtr threadSecurityAttributes, 
        bool inheritHandles, 
        uint creationFlags, 
        IntPtr environment, 
        IntPtr currentDirectory, 
        ref STARTUPINFO startupInfo, 
        ref PROCESS_INFORMATION processInformation   
        );

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern Microsoft.Win32.SafeHandles.SafeFileHandle CreateFile(
        string lpFileName,
        uint dwDesiredAccess, 
        uint dwShareMode,
        SECURITY_ATTRIBUTES lpSecurityAttributes, 
        uint dwCreationDisposition,
        uint dwFlagsAndAttributes, 
        IntPtr hTemplateFile
        );

    [DllImport("ntdll.dll", SetLastError = true)]
    public static extern int NtLockFile(
        SafeFileHandle FileHandle,
        IntPtr Event, 
        IntPtr ApcRoutine,
        IntPtr ApcContext, 
        out IO_STATUS_BLOCK IoStatusBlock,
        ref long ByteOffset, 
        ref long Length,
        uint Key,
        bool FaileImmediately,
        bool ExclusiveLock
        );
         
    [DllImport("ntdll.dll", SetLastError = true)]
    public static extern int NtUnlockFile(
        SafeFileHandle FileHandle,
        out IO_STATUS_BLOCK IoStatusBlock,
        ref long ByteOffset, 
        ref long Length,
        uint Key
        );
         
    [DllImport("kernel32.dll")]
    public static extern bool DuplicateHandle(
        SafeProcessHandle srcProcessHandle,
        IntPtr srcHandle,
        IntPtr targetProcessHandle,
        out IntPtr targetHandle,
        uint desiredAccess,
        bool inheritHandle,
        uint options
        );

    [DllImport("ntdll.dll", SetLastError = true, EntryPoint = "NtQueryInformationProcess", CharSet = CharSet.Unicode)]
    unsafe public static extern uint NtQueryInformationProcess_ProcessHandleInformation_Unsafe(
        SafeProcessHandle ProcessHandle,
        PROCESSINFOCLASS ProcessInformationClass,
        PROCESS_HANDLE_SNAPSHOT_INFORMATION* ProcessInformation,
        uint ProcessInformationLength,
        out uint ReturnLength
        );

    [DllImport("ntdll.dll", SetLastError = true, EntryPoint = "NtQueryObject")]
    public static extern unsafe uint NtQueryObject_Unsafe(
        IntPtr Handle,
        OBJECT_INFORMATION_CLASS ObjectInformationClass,
        PUBLIC_OBJECT_TYPE_INFORMATION* ObjectInformation,
        uint ObjectInformationLength,
        out uint ReturnLength
        );

    [DllImport("Kernel32.dll", SetLastError = true)]
    public static extern SafeProcessHandle OpenProcess(
        uint dwDesiredAccess,
        bool bInheritHandle,
        uint dwProcessId
        );

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint="LookupPrivilegeValueW")]
    public static extern bool LookupPrivilegeValue(
        string lpSystemName,
        string lpName,
        out LUID lpLuid
        );

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool AdjustTokenPrivileges(
        IntPtr TokenHandle,
        bool DisableAllPrivileges,
        ref TOKEN_PRIVILEGES NewState,
        uint BufferLength,
        IntPtr PreviousState,
        IntPtr ReturnLength
        );

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "OpenProcessToken")]
    public static extern bool OpenProcessToken(
        IntPtr ProcessHandle,
        uint DesiredAccess,
        out long TokenHandle
        );

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "GetCurrentProcess")]
    public static extern IntPtr GetCurrentProcess();

}

public class Wrappers
{
    /// <summary>
    /// Count number of objects of type objectTypeName in the current process. This function is currently only
    /// used by tests.
    /// </summary>
    /// <param name="objectTypeName"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public static int GetObjectCount(SafeProcessHandle hProcess, string objectTypeName)
    {
        int objectCount = 0;
        unsafe
        {
            // First call to get required size.
            uint returnLength;
            uint ntStatus;
            int phsiSize = Marshal.SizeOf<PROCESS_HANDLE_SNAPSHOT_INFORMATION>();
            PROCESS_HANDLE_SNAPSHOT_INFORMATION phsiDum;
            ntStatus = Native.NtQueryInformationProcess_ProcessHandleInformation_Unsafe(
                hProcess,
                PROCESSINFOCLASS.ProcessHandleInformation,
                &phsiDum,
                (uint)phsiSize,
                out returnLength
                );
            if (ntStatus != NTSTATUS.STATUS_INFO_LENGTH_MISMATCH)
            {
                throw new Exception(string.Format("NtQueryInformationProcess failed: 0x{0:x}", ntStatus));
            }

            // Second call with buffer size based on returnLength, plus some extra in case some handles
            // get allocated in between.
            phsiSize = (int)returnLength + (Marshal.SizeOf<PROCESS_HANDLE_SNAPSHOT_INFORMATION>() * 20);
            byte* processHandleInformationBuf = stackalloc byte[phsiSize];
            PROCESS_HANDLE_SNAPSHOT_INFORMATION* processHandleInformation =
                (PROCESS_HANDLE_SNAPSHOT_INFORMATION*)processHandleInformationBuf;
            ntStatus = Native.NtQueryInformationProcess_ProcessHandleInformation_Unsafe(
                hProcess,
                PROCESSINFOCLASS.ProcessHandleInformation,
                processHandleInformation,
                (uint)phsiSize,
                out returnLength
                );
            if (ntStatus != NTSTATUS.STATUS_SUCCESS)
            {
                throw new Exception(string.Format("NtQueryInformationProcess failed: 0x{0:x}", ntStatus));
            }

            // Traverse handle list, query the handle type for each.
            int otiBufSize = Marshal.SizeOf<PUBLIC_OBJECT_TYPE_INFORMATION>() + 100;
            byte* objectTypeInformationBuf = stackalloc byte[otiBufSize];
            PUBLIC_OBJECT_TYPE_INFORMATION* objectTypeInfo = 
                (PUBLIC_OBJECT_TYPE_INFORMATION*)objectTypeInformationBuf;
            PROCESS_HANDLE_TABLE_ENTRY_INFO* entry = &processHandleInformation->FirstHandleEntry;
            IntPtr currentProcessHandle = Native.GetCurrentProcess();
            for(int i=0; i < (int)processHandleInformation->NumberOfHandles; ++i, entry++)
            {
                IntPtr handleInThisProcess;
                if (! Native.DuplicateHandle(
                        hProcess, 
                        entry->HandleValue, 
                        currentProcessHandle, 
                        out handleInThisProcess, 
                        ProcessAccessRights.PROCESS_QUERY_INFORMATION,
                        false, 
                        0))
                {
                    // We get ERROR_NOT_SUPPORTED here for some types of handles such as "EtwRegistration".
                    // We don't care about those for our test anyway.
                    continue;
                }

                ntStatus = Native.NtQueryObject_Unsafe(
                    handleInThisProcess,
                    OBJECT_INFORMATION_CLASS.ObjectTypeInformation,
                    objectTypeInfo,
                    (uint)otiBufSize,
                    out returnLength
                    );
                if (ntStatus == NTSTATUS.STATUS_SUCCESS)
                {
                    // Filter based on handle type name
                    string oname = objectTypeInfo->TypeName.ToString();
                    if (oname == objectTypeName)
                    {
                        ++objectCount;
                    }
                }
            }
        }
        return objectCount;
    }

    public static void EnablePrivilege(string privilegeName)
    {
        LUID luid;
        if (!Native.LookupPrivilegeValue(null, privilegeName, out luid))
        {
            Marshal.ThrowExceptionForHR(Marshal.GetHRForLastWin32Error());
        }
        IntPtr currentProcessHandle = Native.GetCurrentProcess();
        long tokenHandle;
        Native.OpenProcessToken(currentProcessHandle, TokenAccessRights.TOKEN_ADJUST_PRIVILEGES,
            out tokenHandle);
        TOKEN_PRIVILEGES privs;
        privs.PrivilegeCount = 1;
        privs.PrivilegesFirstEntry.Luid = luid;
        privs.PrivilegesFirstEntry.Attributes = PrivilegeAccess.SE_PRIVILEGE_ENABLED;
        if (!Native.AdjustTokenPrivileges(
            (IntPtr)tokenHandle, 
            false, 
            ref privs, 
            0, 
            IntPtr.Zero,
            IntPtr.Zero))
        {
            Marshal.ThrowExceptionForHR(Marshal.GetHRForLastWin32Error());
        }
    }

    public static void LockFileWithKey(SafeFileHandle hfile, long offset, long length, uint key)
    {
        IO_STATUS_BLOCK iosb;
        int ntStatus = Native.NtLockFile(hfile, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, out iosb, ref offset, 
            ref length, key, true, true);
        if (ntStatus != NTSTATUS.STATUS_SUCCESS)
        {
            throw new Exception(String.Format("NtLockFile failed: {0:x}", ntStatus));
        }
        if (iosb.status != 0)
        {
            throw new Exception(String.Format("NtLockFile failed [iosb statu]: {0:x}", iosb.status));
        }
    }
    public static void UnlockFileWithKey(SafeFileHandle hfile, long offset, long length, uint key)
    {
        IO_STATUS_BLOCK iosb;
        int ntStatus = Native.NtUnlockFile(hfile, out iosb, ref offset, ref length, key);
        if (ntStatus != NTSTATUS.STATUS_SUCCESS)
        {
            throw new Exception(String.Format("NtUnlockFile failed: {0:x}", ntStatus));
        }
        if (iosb.status != 0)
        {
            throw new Exception(String.Format("NtUnlockFile failed [iosb statu]: {0:x}", iosb.status));
        }
    }
}

'@
$cp = New-Object System.CodeDom.Compiler.CompilerParameters
$cp.ReferencedAssemblies.AddRange(('System.dll', 'System.Diagnostics.Process.dll'))
$cp.CompilerOptions = '/unsafe'
add-type -typedefinition $nativeDef -CompilerParameters $cp

function openOrCreateFile
{
    param 
    (
        $shouldCreate,
        $fileanme
    )
    $coro = [System.IO.FileMode]::open
    if ($shouldCreate -eq $true) 
    {
        $coro = [System.IO.FileMode]::create
    }
    $fs = [system.io.file]::open($filename, $coro, "readwrite", "readwrite")
    if ($shouldCreate -eq $true)
    {
        $sw = [system.io.streamwriter]::new($fs, [System.Text.Encoding]::Unicode, 4096, $true)
        $sw.write("hello")
        $sw.dispose()
    }
    return $fs
}

function getRollbackServiceHandle
{
    [Wrappers]::EnablePrivilege("SeDebugPrivilege")
    $rbProc = get-process rollbackservice -erroraction ignore
    if ($rbProc -eq $null)
    {
        write-host rollbackservice not found
        return $null
    }

    $rbProcHandle = [native]::OpenProcess(
        [ProcessAccessRights]::PROCESS_QUERY_INFORMATION -bor [ProcessAccessRights]::PROCESS_DUP_HANDLE, 
        $false, 
        $rbProc[0].Id
        )
    return $rbProcHandle
}

#
# Returns the number of "section" objet handles are currently open in the rollbackservice process.
#
function verifySectionObjectCount
{
    param
    (
        $rbHandle,
        [int]$expectedCount,
        [string]$message
    )
    $sectionCount = [int][Wrappers]::GetObjectCount($rbHandle, "Section")
    if ($sectionCount -ne $expectedCount)
    {
        write-host $message
        exit 2
    }
}

#
# Lock a region of the file, then modify data in place (no append)
#
function ModifyWithLockTest 
{
    param 
    (
        $shouldCreate,
        $filename
    )

    write-host opening $filename $shouldCreate
    $fs = openOrCreateFile $shouldCreate, $filename;
    write-host locking $filename
    $fs.lock(0,1)
    $sw = [system.io.streamwriter]::new($fs, [System.Text.Encoding]::Unicode, 4096, $true)
    write-host modifying $filename
    $newpos = $fs.seek(0, "begin")
    $sw.write("goodbye")
    $sw.flush()
    $fs.unlock(0,1)
    $sw.close()
}

#
# Lock and unlock a file, verifying the memory map is released at the correct time.
#
function VerifyMapCloseAfterExplicitUnlockTest
{
    param 
    (
        $shouldCreate,
        $filename
    )

    $rbHandle = getRollbackServiceHandle
    if ($rbHandle -eq $null -or $rbHandle.isinvalid)
    {
        write-host "Error, could not find rollbackservice process"
        exit 2
    }

    
    write-host opening $filename
    $sectionObjectsStart = [int][Wrappers]::GetObjectCount($rbHandle, "Section")
    $fs = openOrCreateFile($shouldCreate, $filename);

    write-host locking $filename
    $fs.lock(0,1)
    $expectedCount = $sectionObjectsStart + 1
    verifySectionObjectCount $rbHandle $expectedCount "Error, file mapping closed unexpectedly"

    $sw = [system.io.streamwriter]::new($fs, [System.Text.Encoding]::Unicode, 4096, $true)
    write-host modifying $filename
    $newpos = $fs.seek(0, "begin")
    $sw.write("goodbye")
    $sw.flush()

    write-host unlocking  $filename
    $fs.unlock(0,1)

    verifySectionObjectCount $rbHandle $sectionObjectsStart "Error, file mapping was left open unexpectedly"
   
    $sw.close()
}

#
# Lock a file and the close it without calling Unlock(), verifying the memory map is release at the correct time.
#
function VerifyMapCloseAfterImplicitUnlockTest
{
    param 
    (
        $shouldCreate,
        $filename
    )

    $rbHandle = getRollbackServiceHandle
    if ($rbHandle -eq $null -or $rbHandle.isinvalid)
    {
        write-host "Error, could not find rollbackservice process"
        exit 2
    }

    
    write-host opening $filename
    $sectionObjectsStart = [Wrappers]::GetObjectCount($rbHandle, "Section")
    $fs = openOrCreateFile($shouldCreate, $filename);

    write-host locking $filename
    $fs.lock(0,1)
    $fs.lock(1,1)
    
    $expectedCount = $sectionObjectsStart + 1
    verifySectionObjectCount $rbHandle $expectedCount "Error, file mapping closed unexpectedly"

    write-host closing without excplicit unlock $filename
    $fs.close()

    verifySectionObjectCount $rbHandle $sectionObjectsStart "Error, file mapping was left open unexpectedly"
}

#
# Open multiple handles, verify file mapping state after each locks/unlocks the file.
#
function VerifyMapCloseAfterMultipleHandleLocksTest
{
    param 
    (
        $shouldCreate,
        $filename
    )

    $rbHandle = getRollbackServiceHandle
    if ($rbHandle -eq $null -or $rbHandle.isinvalid)
    {
        write-host "Error, could not find rollbackservice process"
        exit 2
    }
    
    write-host opening $filename
    $sectionObjectsStart = [Wrappers]::GetObjectCount($rbHandle, "Section")
    $fs = openOrCreateFile($shouldCreate, $filename);
    $fs2 = [system.io.file]::open($filename, "open", "write", "readwrite")

    # Lock the file - mapping should be created
    write-host locking 1st handle $filename
    $fs.Lock(0,1)

    # Lock on other handle - 2nd mapping should be created for that handle
    write-host locking 2nd handle $filename
    $fs2.Lock(1,1)

    $expectedCount = $sectionObjectsStart + 2
    verifySectionObjectCount $rbHandle $expectedCount "Error, file mapping closed unexpectedly"

    # Unlock one of the handles - 1 mapping should still be in place
    write-host unlocking 1st handle $filename
    $fs.Unlock(0, 1)

    $expectedCount = $sectionObjectsStart + 1
    verifySectionObjectCount $rbHandle $expectedCount "Error, file mapping closed unexpectedly"

    # Unlock the file incorrectly, so the operation fails - mapping should still be in place
    write-host re-unlocking 1st handle $filename
    $unlockFailed = $false
    try { $fs.Unlock(0, 1) } catch { $unlockFailed = $true }
    if (! $unlockFailed) 
    {
        write-host "Unlock did not fail as expected"
        exit 2
    }
    $expectedCount = $sectionObjectsStart + 1
    verifySectionObjectCount $rbHandle $expectedCount "Error, file mapping closed unexpectedly"

    # Release final lock - this should release the file mapping
    write-host unlocking 2nd handle $filename
    $fs2.Unlock(1, 1);

    verifySectionObjectCount $rbHandle $sectionObjectsStart "Error, file mapping was left open unexpectedly"
}


if ($args.Count -eq 0)
{
    write-host 'Usage:'
    write-host 'locktests <cmd>'
    write-host ''
    write-host 'cmds:'
    write-host ' modifywithlock filename'
    write-host ' verifymapcloseexplicit filename'
    write-host ' verifymapcloseimplicit filename'
    write-host ' verifymapclosemultihandle filename'
    Write-Host
    exit 1
}

$shouldCreateInitialFile = $true;
$argi=0;
for($argn=0; $argn -lt $args.count; ++$argn)
{
    $arg = $args[$argn]
    if ($arg -eq '-nocreate')
    {
        $shouldCreateInitialFile = $false
    }
    else 
    {
        switch ($argi)
        {
            0 { $cmd = $args[$argi] }
            1 { $filename = $args[$argi] }
            default {}
        }
        ++$argi          
    }
}

write-host $cmd $filename $shouldCreateInitialFile

#powershell -file locktests.ps1 modifywithlock c:\test\test.txt -nocreate
switch ($cmd)
{
    "modifywithlock" { ModifyWithLockTest $shouldCreateInitialFile $filename }
    "verifymapcloseexplicit" { VerifyMapCloseAfterExplicitUnlockTest $shouldCreateInitialFile $filename }
    "verifymapcloseimplicit" { VerifyMapCloseAfterImplicitUnlockTest $shouldCreateInitialFile $filename }
    "verifymapclosemultihandle" { VerifyMapCloseAfterMultipleHandleLocksTest $shouldCreateInitialFile $filename }
    default 
    { 
        write-host Unknown command $cmd
        exit 1
    }
}

