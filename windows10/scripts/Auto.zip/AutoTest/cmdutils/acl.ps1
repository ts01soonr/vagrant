﻿$MethodDefinition = @'
[DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
public static extern Microsoft.Win32.SafeHandles.SafeFileHandle CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);
'@

if(3 -le $args.Length ){
    $Path= $args[0]
    $Type= $args[1]
    $OP= $args[2]
 
    if($Type.Equals("access")) {
        $ACL = Get-ACL -Path $Path
        $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone","Read","Allow")
        if($OP.Equals("add")) { 
            $ACL.SetAccessRule($AccessRule)
            $ACL | Set-Acl -Path $Path
        }
        elseif($OP.Equals("x")) { 
            $ACL.RemoveAccessRule($AccessRule) 
            $ACL | Set-Acl -Path $Path
        }
        (Get-ACL -Path $Path).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize
        exit 
    }
    if($Type.Equals("audit")) {
        $AuditUser = "Everyone"
        $AuditRules = "Delete,DeleteSubdirectoriesAndFiles,ChangePermissions,Takeownership"
        $InheritType = "ContainerInherit,ObjectInherit"
        $AuditType = "Success"
        $AccessRule = New-Object System.Security.AccessControl.FileSystemAuditRule($AuditUser,$AuditRules,$InheritType,"None",$AuditType)
        $ACL = Get-Acl $Path
        if($OP.Equals("add") ) { 
            $ACL.SetAuditRule($AccessRule)
            $ACL | Set-Acl $Path
        }
        elseif($OP.Equals("x") ) { 
            $ACL.RemoveAuditRuleSpecific($AccessRule)
            $ACL | Set-Acl $Path
        }
        #Write-Host "Processing >",$Path
        #$ACL | Set-Acl $Path
        Get-Acl -Audit $Path | format-list
        exit 
    }
    if($Type.Equals("owner")) {
        $ACL = Get-Acl -Path $Path
        $User = New-Object System.Security.Principal.Ntaccount($env:UserName)
        $ACL.SetOwner($User)
        $ACL | Set-Acl -Path $Path
        (Get-ACL -Path $Path).Owner
        exit
    }
    if($Type.Equals("group")) {

        $ACL = Get-Acl -Path $Path
        #write-host Current primary group for $Path : $acl.Group

        # Update the group to "Backup Operators"
        #write-host Updating group...
        $groupSid = [System.Security.Principal.SecurityIdentifier]::new([System.Security.Principal.WellKnownSidType]::BuiltinBackupOperatorsSid,$null)
        
        if($OP.Equals("add") ) {
            $acl.SetGroup($groupSid)
            Set-Acl $Path $acl
        }
        # write the acl
        # dump the group again
        $ACL | Set-Acl -Path $Path
        (Get-ACL -Path $Path).Group
        exit
    }
    if($Type.Equals("delete")) {
        # double delete
        # acl.ps1 file_path delete 2
        if (-not (Test-Path $Path) ) {
            echo %date%-%time% > $Path
        }
        $native = Add-Type -MemberDefinition $MethodDefinition -Name 'native' -Namespace 'winutil' -PassThru
        $FILE_FLAG_DELETE_ON_CLOSE = 0x04000000
        $FILE_READ_DATA = 0x0001
        $DELETE = 0x00010000
        $OPEN_EXISTING = 3
        $FILE_SHARE_READ = 0x00000001
        $FILE_SHARE_DELETE = 0x00000004
        $al = [System.Collections.ArrayList]::new();
        for ($i = 1; $i -le $OP; $i++) {
            $al.Add($native::CreateFile($Path, $FILE_READ_DATA -bor $DELETE, $FILE_SHARE_DELETE -bor $FILE_SHARE_READ, 0, $OPEN_EXISTING, $FILE_FLAG_DELETE_ON_CLOSE, 0))
        }
        for ($i = 1; $i -le $OP; $i++) {
            $al[$i-1].Close()
        }
        exit
    }
    if($Type.Equals("rmdir")) {
        # FILE_FLAG_DELETE_ON_CLOSE
        # taget:folder
        if (-not (Test-Path $Path) ) {
            mkdir $Path
        }
        $native = Add-Type -MemberDefinition $MethodDefinition -Name 'native' -Namespace 'winutil' -PassThru
        $al = [System.Collections.ArrayList]::new();
        for ($i = 1; $i -le $OP; $i++) {
            $h = $native::CreateFile($Path, 0x10000000, 0, 0, 3, 0x06000000, 0)
            $al.Add($h)
        }
        $lastErr = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
        if ($h.IsInvalid)
        {
            write-host Error: CreateFile failed: $lastErr
            exit 1
        }
        for ($i = 1; $i -le $OP; $i++) { $al[$i-1].Close() }
        exit
    }
}