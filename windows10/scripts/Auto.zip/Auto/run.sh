#! /bin/bash

######
# run jar with output log in background.
# java -jar soonr.jar > out.log 2>&1 &
######

cd /Auto
/usr/bin/java -jar soonr.jar > out.log

