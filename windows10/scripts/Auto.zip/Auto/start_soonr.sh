#!/bin/bash
cd /Auto
java -jar soonr.jar

