#!/bin/sh
cd /Auto
python setup.py

