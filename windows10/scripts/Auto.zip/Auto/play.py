import sys
import os
import subprocess
import urllib2
import telnetlib
import time
# print 'Number of arguments:', len(sys.argv), 'arguments.'
# print 'Argument List:', str(sys.argv)
UN="admin"
pn= len(sys.argv)
# play.py aeb i/x
p1 = ""
p2 = ""
p3 = ""
p4 = ""
p5 = ""
p6 = ""
p7 = ""
if pn > 1 :
   p1=sys.argv[1]   
if pn > 2 :
   p2=sys.argv[2]
if pn > 3 :
   p3=sys.argv[3]
if pn > 4 :
   p4=sys.argv[4]
if pn > 5 :
   p5=sys.argv[5]
if pn > 6 :
   p6=sys.argv[6]
if pn > 7 :
   p7=sys.argv[7]

   # print p1, p2, p3
all = (p1+" "+p2+" "+ p3+" "+p4+" "+p5+" "+p6+" "+p7).strip()
p27=(p2+" "+ p3+" "+p4+" "+p5+" "+p6+" "+p7).strip()
p37=(p3+" "+p4+" "+p5+" "+p6+" "+p7).strip()
if p2=="i" and p4=="i":
   # play dwc i i i lab2, no index for mac agent
   p4=""
if p1=="aeb" or p1=="a" :

   if p2=="i":
      # print "install agent ", p3 , p4
      subprocess.call(["a/aeb_i.sh",p3,p4])
   elif p2=="x":
      #print "uninstall agent"
      subprocess.call("a/aeb_x.sh")
   elif p2=="mi":
      #print "bash a/aeb_i.sh "+ p3 +" "+ p4 + " > log/install.log"
      os.system("a/aeb_i.sh "+ p3 +" "+ p4 + " > log/install.log")
      print "logs> run cat log/install.log"
   elif p2=="mx":
      #print "bash a/aeb_x.sh > log/uninstall.log"
      os.system("a/aeb_x.sh > log/uninstall.log")
      print "logs> run cat log/uninstall.log"
   elif p2=="d":
      if p3=="":
         p3="http://hb.35cloud.com/file/agent/AT/AEB.dmg"
      print "download url"
      f = urllib2.urlopen(p3)
      with open("a/AEB"+p4+".dmg", "wb") as code:
           code.write(f.read())
   elif p2=="ver":
      os.system("mdls -name kMDItemVersion /Applications/Autotask\ Endpoint\ Backup.app/")
   else:
      print "unkown params(i,x,mi,mx,d)"
elif p1=="dfp" or p1=="p" :

   if p2=="i":
      # print "install dpf agent ", p3 , p4
      subprocess.call(["a/dfp_i.sh",p3,p4])
   elif p2=="x":
      #print "uninstall dpf agent"
      subprocess.call("a/dfp_x.sh")
   elif p2=="mi":
      #print "bash a/dfp_i.sh "+ p3 +" "+ p4 + " > log/dfp_install.log"
      os.system("a/dfp_i.sh "+ p3 +" "+ p4 + " > log/dfp_install.log")
      print "logs> run cat log/dpf_install.log"
   elif p2=="mx":
      #print "bash a/dfp_x.sh > log/dfp_uninstall.log"
      os.system("a/dfp_x.sh > log/dfp_uninstall.log")
      print "logs> run cat log/dfp_uninstall.log"              
   elif p2=="d":
      if p3=="":
         p3="http://hb.35cloud.com/file/agent/DFP.dmg"
      print "download url"
      f = urllib2.urlopen(p3)
      with open("a/DFP"+p4+".dmg", "wb") as code:
           code.write(f.read())  
   elif p2=="ver":
      os.system("mdls -name kMDItemVersion /Applications/Datto\ File\ Protection.app/")
   else:
      print "unkown params(i,x,mi,mx,d)" 

elif p1=="awp" or p1=="w" :
   if p2=="i":
      # print "install agent ", p3 , p4
      subprocess.call(["a/awp_i.sh",p3,p4])
   elif p2=="x":
      #print "uninstall agent"
     subprocess.call("a/awp_x.sh")
   elif p2=="mi":
      #print "bash a/awp_i.sh "+ p3 +" "+ p4 + " > log/install.log"
      os.system("a/awp_i.sh "+ p3 +" "+ p4 + " > log/install.log")
      print "logs> run cat log/install.log"
   elif p2=="mx":
      #print "bash a/awp_x.sh > log/uninstall.log"
      os.system("a/awp_x.sh > log/uninstall.log")
      print "logs> run cat log/uninstall.log"              
   elif p2=="d":
      if p3=="":
         p3="http://hb.35cloud.com/file/agent/AT/AWP.dmg"
      #print "download AWP"+p4+".dmg"
      f = urllib2.urlopen(p3)
      with open("a/AWP"+p4+".dmg", "wb") as code:
           code.write(f.read())  
   elif p2=="ver":
      os.system("mdls -name kMDItemVersion /Applications/Autotask\ Workplace\ Desktop.app/")
   else:
      print "unkown params(i,x,mi,mx,d)" 
      
elif p1=="dwp" or p1=="d" :
   if p2=="i":
      # print "install DWP agent ", p3 , p4
      subprocess.call(["a/dwp_i.sh",p3,p4])
   elif p2=="x":
      #print "uninstall DWP agent"
     subprocess.call("a/dwp_x.sh")
   elif p2=="mi":
      #print "bash a/dwp_i.sh "+ p3 +" "+ p4 + " > log/DWPinstall.log"
      os.system("a/dwp_i.sh "+ p3 +" "+ p4 + " > log/DWPinstall.log")
      print "logs> run cat log/DWPinstall.log"
   elif p2=="mx":
      #print "bash a/dwp_x.sh > log/DWPuninstall.log"
      os.system("a/dwp_x.sh > log/DWPuninstall.log")
      print "logs> run cat log/DWPuninstall.log"
   elif p2=="d":
      if p3=="":
         p3="http://hb.35cloud.com/file/agent/DWP.dmg"
      #print "download DWP"+p4+".dmg"
      f = urllib2.urlopen(p3)
      with open("a/DWP"+p4+".dmg", "wb") as code:
           code.write(f.read())
   elif p2=="ver":
      os.system("mdls -name kMDItemVersion /Applications/Datto\ Workplace\ Desktop.app/")
   else:
      print "unkown params(i,x,mi,mx,d)"

elif p1=="dwc" or p1=="c" :
   if p2=="i":
      # print "install DWC agent ", p3 , p4
      subprocess.call(["a/dwc_i.sh",p3,p4])
   elif p2=="x":
      #print "uninstall DWC agent"
     subprocess.call("a/dwc_x.sh")
   elif p2=="mi":
      #print "bash a/dwc_i.sh "+ p3 +" "+ p4 + " > log/DWCinstall.log"
      os.system("a/dwc_i.sh "+ p3 +" "+ p4 + " > log/DWCinstall.log")
      print "logs> run cat log/DWPinstall.log"
   elif p2=="mx":
      #print "bash a/dwc_x.sh > log/DWCuninstall.log"
      os.system("a/dwc_x.sh > log/DWCuninstall.log")
      print "logs> run cat log/DWCuninstall.log"
   elif p2=="d":
      if p3=="":
         p3="http://hb.35cloud.com/file/agent/DWC.dmg"
      #print "download DWC"+p4+".dmg"
      if os.path.exists("a/DWC"+p4+".dmg"):      
         os.remove("a/DWC"+p4+".dmg")
      f = urllib2.urlopen(p3)
      with open("a/DWC"+p4+".dmg", "wb") as code:
           code.write(f.read())
   elif p2=="ver":
      os.system("mdls -name kMDItemVersion /Applications/Datto\ Workplace.app/")
   elif p2=="link":
      os.system("ln -s '/Users/"+UN+"/"+p37+"' /Users/"+UN+"/Workplace");	
   else:
      print "unkown params(i,x,mi,mx,d)"
elif p1=="aos":
   if p2=="d":
      if p3=="":
         p3="http://hb.35cloud.com/file/agent/VFSx.apk"
      #print "download VFSx"+p4+".apk"
      if os.path.exists("a/VFSx"+p4+".apk"):      
         os.remove("a/VFSx"+p4+".apk")
      f = urllib2.urlopen(p3)
      with open("a/VFSx"+p4+".apk", "wb") as code:
           code.write(f.read())   
   elif p2=="r":
      video="video.mp4"
      if p3<>"":
      	video=p3
      os.system("adb shell screenrecord /sdcard/"+video);      	
   elif p2=="p":
      video="video.mp4"
      if p3<>"":
      	video=p3
      os.system("killall adb");
      os.system("adb pull /sdcard/"+video);
      #print "adb pull /sdcard/"+video 
elif p1=="fget" :
     # download file from url
      if p2=="" or p3=="" :
        sys.exit(0)
      # print "download url"
      f = urllib2.urlopen(p3)
      with open(p2, "wb") as code:
           code.write(f.read())
elif p1=="shell" :     
     os.system(p27)
elif p1=="sh" :     
     os.system("bash " + p2 + ".sh  > log/file2.log")
elif p1=="login" or p1=="loginc" or p1=="teamkey" :	 
	 os.system("osascript os.scpt "+ all)
elif p1=="check" or p1=="select" or p1=="unselect" :	 
	 os.system("osascript os.scpt "+ all)
elif p1=="rid" or p1=="uid" or p1=="dis" or p1=="con" or p1=="open" or p1=="close" or p1=="start" or p1=="retry":
	 os.system("osascript os.scpt "+ all)
elif p1=="logout" :     
	HOST = "localhost"
	port = 8888
	if p2!="":
		port=int(p2)
	tn = telnetlib.Telnet()
	tn.open(HOST,port)
	tn.read_until("\n")
	tn.write("stop\n")
	tn.sock.close()
	os.system("osascript -e 'tell application \"System Events\" to log out'")
	os.system("osascript -e 'tell application \"System Events\" to key code 52'")
	os.system("osascript -e 'tell application \"System Events\" to key code 52'")    

else:
   print "unknow command(aeb,a,fget,sh)"
