#!/bin/bash
echo silent_uninstall.sh com.datto.dwc '"'Datto Workplace'"' dwcPreferencePane 0
a/silent_uninstall.sh com.datto.dwc "Datto Workplace" dwcPreferencePane 0
