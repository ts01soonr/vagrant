#!/bin/bash
#workplace installer build 13b/seagull

#set initial exit code to zero
varExitLevel=0

echo "Software: Datto Workplace for macOS"
echo "=========================================="

DMG="a/AWP.dmg"
if test -z "$2" ; then
	DMG="a/DWP.dmg"
else
    DMG="a/DWP$2.dmg"
fi
KEY=$1
if [ "$1" == "i" ] ; then
   	KEY=""
fi

#remove AWP first
if [ -d "/Applications/Autotask Workplace Desktop.app" ];
then
	echo "- Removing prior installation of Autotask Workplace..."
	cp "/Library/Preferences/com.autotask.awp.teamkey" "/Library/Preferences/com.datto.dwp.teamkey" 2>/dev/null 
	./silent_uninstall.sh com.autotask.awp "Autotask Workplace Desktop" awpPreferencePane 1
fi

echo TeamKey=${KEY} ...
echo silent_install.sh '"'${DMG}'"' '"'Datto Workplace Desktop'"' com.datto.dwp ${KEY}
echo "- Installing..."
a/silent_install.sh ${DMG} "Datto Workplace Desktop" com.datto.dwp ${KEY}

echo =============================================

if [ $varExitLevel -eq 0 ] 
then
	echo "- Operation successful"
	exit
else
	echo "- Operation completed with errors (exit code $varExitLevel)."
	echo "  If you are attempting to remove Autotask Workplace, please first install Datto"
	echo "  Workplace, then re-run this Component with the Uninstall flag set to TRUE."
	echo "  Autotask Workplace installations will automatically upgrade to Datto Workplace."
	exit 1
fi