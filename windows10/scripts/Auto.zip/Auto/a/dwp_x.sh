#!/bin/bash
echo silent_uninstall.sh com.datto.dwp '"'Datto Workplace Desktop'"' dwpPreferencePane 0
a/silent_uninstall.sh com.datto.dwp "Datto Workplace Desktop" dwpPreferencePane 0
