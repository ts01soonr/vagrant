#!/bin/bash
echo "..."
#set initial exit code to zero
varExitLevel=0
echo "Software: Datto File Protection for macOS"
echo "=========================================="
DMG="a/DFP.dmg"
if test -z "$2" ; then
	DMG="a/DFP.dmg"
else
    DMG="a/DFP$2.dmg"
fi
KEY=$1
if [ "$1" == "i" ] ; then
   	KEY=""
fi
echo TeamKey=${KEY} ...

#remove AEB first
if [ -d "/Applications/Autotask Endpoint Backup.app" ];
then
	echo "- Removing prior installation of Autotask Endpoint Backup..."
	cp "/Library/Preferences/com.autotask.aeb.teamkey" "/Library/Preferences/com.datto.dfp.teamkey" 2>/dev/null 
	a/silent_uninstall.sh com.autotask.aeb "Autotask Endpoint Backup" aebPreferencePane 1
fi
echo "- Installing..."
echo silent_install.sh '"'${DMG}'"' '"'Datto File Protection'"' com.datto.dfp ${KEY}
a/silent_install.sh ${DMG} "Datto File Protection" com.datto.dfp ${KEY}
varExitLevel=$(echo "$? + $varExitLevel" | bc)
if [ $varExitLevel -eq 0 ]; then
	echo "- Operation successful"
	exit
else
	echo "- Operation completed with errors (exit code $varExitLevel)."
	echo "  If you are attempting to remove Autotask Endpoint Backup, please first install Datto"
	echo "  File Protection, then re-run this Component with the Uninstall flag set to TRUE."
	echo "  Autotask Endpoint Backup installations will automatically upgrade to File Protection."
	exit 1
fi
