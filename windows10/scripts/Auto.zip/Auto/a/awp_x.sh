#!/bin/bash
echo silent_uninstall.sh com.autotask.awp '"'Autotask Workplace Desktop'"' awpPreferencePane 0
a/silent_uninstall.sh com.autotask.awp "Autotask Workplace Desktop" awpPreferencePane 0
