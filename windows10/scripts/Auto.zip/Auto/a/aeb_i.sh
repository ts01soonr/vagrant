#!/bin/bash
echo "..."
DMG="a/AEB.dmg"
if test -z "$2" ; then
	DMG="a/AEB.dmg"
else
    	DMG="a/AEB$2.dmg"
fi
KEY=$1
if [ "$1" == "i" ] ; then
   	KEY=""
fi
echo TeamKey=${KEY} ...
echo silent_install.sh '"'${DMG}'"' '"'Autotask Endpoint Backup'"' com.autotask.aeb ${KEY}
a/silent_install.sh ${DMG} "Autotask Endpoint Backup" com.autotask.aeb ${KEY}
