#! /bin/bash
echo silent_uninstall.sh com.autotask.aeb '"'Autotask Endpoint Backup'"' aebPreferencePane 0
a/silent_uninstall.sh com.autotask.aeb "Autotask Endpoint Backup" aebPreferencePane 0
