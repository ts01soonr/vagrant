#! /bin/bash

### version 1.0.3
### latest changes:
###		- added ACL rule for chown change for admin group
###		- fixed version detection for big sur
###		- workaround for calling "open" on big sur+

####
# input parameters: silent_install.sh <path_to_dmg> <application_name> <application_identifier> <team_key>
#
# example: ./silent_install.sh "Autotask Endpoint Backup.dmg" "Autotask Endpoint Backup" com.autotask.aeb 123abc456
# example: ./silent_install.sh "AutotaskWorkplace.dmg" "Autotask Workplace" com.autotask.awp 123abc456
#
# <path_to_dmg> this parameter is relative or absolute path to �.dmg� image. Can be absolute or relative to work folder
# <application_name> is name of application to copy from dmg volume. For Soonr brand it is �SoonrAgent�. For AEB it is "Autotask Endpoint Backup"
# <application_identifier> is applicaiton identifier. For AEB: com.autotask.aeb for AWP: com.autotask.awp
# <team_key> team key string to be saved into file for agent setup process. This parameter is not mandatory.
#
# If application is installed prior to running this script, it is upgraded.
# If only first, second and third, parameter are present, upgrade is done without changing team key.
# 
# This script with reinit installation for all users that have been rejected previously, and reset team key to new one
#
# For installing Mac Agent, use installation script: �silent_install.sh�.
# Script has to be copied over to target machine together with �.dmg� image containing application. 
# Script needs correct execution permissions.
#
# Whole process may be repeated. If so, team key is reset to new value and silent installation is setup to be run, however silent installation will be run for user only if he has not a valid account.
####

TestZero()
{
	ret=$?
	if [ $ret -ne 0 ]; then
		echo "Failed with error: $1 code: $ret"
		exit $ret
	fi
}

APPLICATION_NAME="$2"
APPLICATION_IDENTIFIER="$3"

if test -z "$1" || test -z "$2" || test -z "$3"; then
	echo "First three input parameters are mandatory"
	exit 1
fi

#test for system version
MAJOR_MAC_VERSION=$(sw_vers -productVersion | awk -F '.' '{print $1}')
MINOR_MAC_VERSION=$(sw_vers -productVersion | awk -F '.' '{print $2}')

if ((MAJOR_MAC_VERSION < 10 || ( MAJOR_MAC_VERSION == 10 && MINOR_MAC_VERSION < 8))); then
	echo "Installation failed with error 20: Unsupported macOS version. Minimum macOS version is 10.8."
	exit 20
fi

SOURCE_DIR="/Volumes/InstallAgent/${APPLICATION_NAME}.app"

# mount it
DEV_NAME=$(hdiutil attach -mountpoint "/Volumes/InstallAgent" "$1")
TestZero "unable to mount"

#delete it
rm -rf "/Applications/${APPLICATION_NAME}.app"
TestZero "unable to delete original application"

#copy it
cp -r "${SOURCE_DIR}" "/Applications"
TestZero "unable to copy"

#detach
hdiutil detach "/Volumes/InstallAgent"
TestZero "unable to detach image"

#set permissions
chmod -R 777 "/Applications/${APPLICATION_NAME}.app"
TestZero "unable to change chmod for application"

chmod +a "admin allow chown" "/Applications/${APPLICATION_NAME}.app" 

TEAMKEY_PATH="/Library/Preferences/${APPLICATION_IDENTIFIER}.teamkey"

SILENT_INSTALLER_SOURCE_PATH="/Applications/${APPLICATION_NAME}.app/Contents/Resources/${APPLICATION_IDENTIFIER}.installer.plist"
SILENT_INSTALLER_TARGET_PATH="/Library/LaunchAgents/${APPLICATION_IDENTIFIER}.installer.plist"

# delete (6.0-AEB) AEB installer plist
rm -f "/Library/LaunchAgents/com.autotask.installer.plist"

if test -z "$4"; then
	echo "Team key was not updated"
else
	#save teamkey into file
	$(echo "$4" > $TEAMKEY_PATH)
	TestZero "unable to save teamkey"
	echo "Team key ($4) saved"

	chmod 644 "${TEAMKEY_PATH}"
	TestZero "unable to set chmod on teamkey file"
fi

#copy silent installer launch agent
cp "${SILENT_INSTALLER_SOURCE_PATH}" "${SILENT_INSTALLER_TARGET_PATH}"
TestZero "unable to copy silent installer plist"

chown root:wheel "${SILENT_INSTALLER_TARGET_PATH}"
TestZero "unable to set silent installer plist owner"

chmod 755 "${SILENT_INSTALLER_TARGET_PATH}"
TestZero "unable to set chmod for installer plist"

#### disabled  ####
#remove disables for all users  
#for user in $(dscl . list /Users | grep -v false | grep "^[^_]")
#do
#	rm -f "/Users/${user}/Library/Preferences/com.autotask.silent_installer_disabled"
#	TestZero
#	echo "Silent installer reinitialized for user: ${user}"
#done

if ((MAJOR_MAC_VERSION >= 11)); then
	loggedInUser=$( echo "show State:/Users/ConsoleUser" | scutil | awk '/Name :/ && ! /loginwindow/ { print $3 }' )
	# test if a user is logged in
	if [ -n "$loggedInUser" ]; then
		echo "sudo open for user: ${loggedInUser}"
		sudo -u "$loggedInUser" open -n -a "/Applications/${APPLICATION_NAME}.app" --args upgraded 2>/dev/null
	else
		echo "No user logged in, skipping restart after upgrade"
	fi
else
	# does not work since big sur, seems to be an issue on how RMM runs a script (as root)
	open -n -a "/Applications/${APPLICATION_NAME}.app" --args upgraded 2>/dev/null
fi

echo "Finished successfully!"
exit 0
