#! /bin/bash
echo silent_uninstall.sh com.datto.dfp '"'Datto File Protection'"' dfpPreferencePane 0
a/silent_uninstall.sh com.datto.dfp "Datto File Protection" dfpPreferencePane 0
