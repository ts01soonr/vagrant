#!/bin/bash
echo "..."
DMG="a/AWP.dmg"
if test -z "$2" ; then
	DMG="a/DWC.dmg"
else
    	DMG="a/DWC$2.dmg"
fi
KEY=$1
if [ "$1" == "i" ] ; then
   	KEY=""
fi
echo TeamKey=${KEY} ...
echo silent_install.sh '"'${DMG}'"' '"'Datto Workplace'"' com.datto.dwc ${KEY}
a/silent_install.sh ${DMG} "Datto Workplace" com.datto.dwc ${KEY}
