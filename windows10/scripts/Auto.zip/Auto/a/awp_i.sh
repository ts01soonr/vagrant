#!/bin/bash
echo "..."
DMG="a/AWP.dmg"
if test -z "$2" ; then
	DMG="a/AWP.dmg"
else
    	DMG="a/AWP$2.dmg"
fi
KEY=$1
if [ "$1" == "i" ] ; then
   	KEY=""
fi
echo TeamKey=${KEY} ...
echo silent_install.sh '"'${DMG}'"' '"'Autotask Workplace Desktop'"' com.autotask.awp ${KEY}
a/silent_install.sh ${DMG} "Autotask Workplace Desktop" com.autotask.awp ${KEY}
