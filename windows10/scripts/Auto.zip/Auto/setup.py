import sys
import os
import subprocess
import urllib2
import zipfile
import shutil

sjar= "https://lab6.soonr.com/1/filelink/rny-r2jpm-ymjeg7vc"
mac = "https://lab6.soonr.com/1/filelink/rny-u3qzo-mpl25jug"
plist="/Library/LaunchDaemons/com.soonr.Fang.plist"

# download soonr.jar
if not os.path.exists("soonr.jar") :
      print "download soonr.jar"
      f = urllib2.urlopen(sjar)
      with open("soonr.jar", "wb") as code:
           code.write(f.read())  
if not os.path.exists("log"):
      os.system("mkdir log")
if not os.path.exists(plist):
      print "setup daemon for soonr.jar"
      shutil.copy2('com.soonr.Fang.plist', plist)
os.system("rm *.bat")
os.system("rm a/*.bat")
os.system("rm -rf p")
os.system("rm -rf s")
os.system("rm *.exe")      
os.system("chmod +x *.sh")
os.system("chmod +x a/*.sh")
os.system("launchctl unload /Library/LaunchDaemons/com.soonr.Fang.plist")      
os.system("launchctl load /Library/LaunchDaemons/com.soonr.Fang.plist")
print "......"
print " soonr.jar is running as daemon System service - Done"
