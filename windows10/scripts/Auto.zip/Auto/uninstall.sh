#!/bin/sh
launchctl unload /Library/LaunchDaemons/com.soonr.Fang.plist
rm /Library/LaunchDaemons/com.soonr.Fang.plist
