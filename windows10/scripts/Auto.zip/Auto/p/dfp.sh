#!/bin/bash
# datto file protection monitor for macOS :: adapted by seagull & f. zhiyong/version 1.5

DiffB=0
warn=0
AlertShow=0
MessageAlertLast=0
MessageAlert=""
HRsize=""
hasProcess=0


ServiceStatus=true
SubStatus=true
BackupWarning=true
InstallStatus=true
LastComplete=true
backupDays=1


# Convert Byte into Human Size
function bytesToHR()
{
  local SIZE=$1
  local UNITS="B KB MB GB"
  for F in $UNITS; do
    local UNIT=$F
    test ${SIZE%.*} -lt 1024 && break;
    SIZE=$(echo "$SIZE / 1024" | bc -l)
  done
  if [ "$UNIT" == "B" ]; then
    HRsize=$(printf "%4.0f %s\n" $SIZE $UNIT)
  else
    HRsize=$(printf "%7.02f %s\n" $SIZE $UNIT)
  fi
}


if [ ! -d "/Applications/Datto File Protection.app/" ]; then
	echo "<-Start Result->"
	echo "CSMon_Result=File Protection is not installed"
	echo "<-End Result->"
	exit 1
else
    	
	for user in $(ls /Users/) 
	do
		# ignore those default System users
		if [[ "$user" = ".localized" || "$user" = "Shared" ]]; then
			continue
		fi
		
		# Lookup for running agent only			
		if [ $(pgrep -U $user "Datto\ File\ Protection") > '0' ]; then
			hasProcess=1
			#Status Report.xml
			XmlFile="/Users/$user/Library/Preferences/com.datto.dfp/Status Report.xml"
			if [ -f "$XmlFile" ]; then
				while IFS= read -r line
				do
					#service status
					if [[ "$line" == *\"agent-online\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						AgentOnline=${arr[0]}
						if [[ "$ServiceStatus" == "true" && "$AgentOnline" == "disconnected" ]]; then
							AlertShow=1;
							MessageAlert="$MessageAlert File Protection: $AgentOnline | ";
						fi;
					fi;
					#Subscription status (disabled in logfile)
					if [[ "$line" == *\"agent-subscription-status\"* ]]; then
						if [ "$SubStatus" = "true" ]; then
							IFS='>' read -r -a array <<< "$line"
							IFS='<' read -r -a arr <<< "${array[1]}"
							Subscr="Subscription status: ${arr[0]} | "
							if [ "${arr[0]}" != "enabled" ]; then
								AlertShow=1
								MessageAlert="$MessageAlert $Subscr";
							fi;
						else
							Subscr="";
						fi;
					fi;
					#Backup Warning 
					if [[ "$line" == *\"backup-warning\"* ]]; then
						if [ "$BackupWarning" = "true" ]; then
							IFS='>' read -r -a array <<< "$line"
							IFS='<' read -r -a arr <<< "${array[1]}"
							if [ ${arr[0]} ]; then
								AlertShow=1
								BackWarn="Backup Warning: ${arr[0]} | ";
								MessageAlert="$MessageAlert $BackWarn"
							else
								BackWarn="Backup Warning: No warning | ";
							fi;
						else
							BackWarn="";
						fi;
					fi;
					#Last Complete Backup
					if [[ "$line" == *\"backup-last-complete\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						BackupLast=${arr[0]};
					fi;
					#XX MB left to Backup
					if [[ "$line" == *\"backup-bytes-remaining\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						LeftBackup=${arr[0]}
						bytesToHR ${arr[0]}						
						LeftSize=$HRsize;
					fi;
					#Backup Size
					if [[ "$line" == *\"backup-numbytes\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						bytesToHR ${arr[0]}
						FullSize="Backup Size: $HRsize | "
					fi;
					#Backup Remaning (sec)
					if [[ "$line" == *\"backup-timeleft\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						BackupRemaning=${arr[0]};
					fi;
					#Restore Size
					if [[ "$line" == *\"restore-bytes\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						bytesToHR ${arr[0]}
						RestoreSize=$HRsize;
					fi;
					#Restore Remaning
					if [[ "$line" == *\"restore-time\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						RestoreRemaning=${arr[0]};
					fi;
					#Backup active
					if [[ "$line" == *\"backup-active\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						BackupActive=${arr[0]};
					fi;
					#Restore active
					if [[ "$line" == *\"restore-active\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						RestoreActive=${arr[0]};
					fi;
					#server imposed backup delay (for problem files) in seconds
					if [[ "$line" == *\"backup-error-delay\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						BackupErrorDelay=${arr[0]};
					fi;
					#Install Status
					if [ "$InstallStatus" = "true" ]; then
						if [[ "$line" == *\"setup-deployment-status\"* ]]; then
							IFS='>' read -r -a array <<< "$line"
							IFS='<' read -r -a arr <<< "${array[1]}"
							StatInst="Installation Status: ${arr[0]}| ";
							if [ "${arr[0]}" != "finished" ]; then
								AlertShow=1
								MessageAlert="$MessageAlert $StatInst";
							fi;
						fi;
					else
						StatInst="";
					fi;
					#DFP Version
					if [[ "$line" == *\"agent-version\"* ]]; then
						IFS='>' read -r -a array <<< "$line"
						IFS='<' read -r -a arr <<< "${array[1]}"
						AEB_Version=${arr[0]};
					fi;
					#AEB Agent ID
					if [[ "$line" == *rcid=* && "$AEBAgentID" == "$Null" ]]; then
						step=${line:48:25}
						step2=${step#*\"};
						AEBAgentID=${step2%\"*};
					fi;
					#status-report tag now
					if [[ "$line" == *status-report* && "$XMLUpdateFile" == "$Null" ]]; then
						IFS='"' read -r -a array <<< "$line"
						XMLUpdateFile=${array[1]}
					fi;
				done <"$XmlFile"
				
				# ###################################
				DateNow=$(date +%s)
				#600
				let "DiffTimeOn = DateNow - XMLUpdateFile"
				if [[ "$DiffTimeOn" -gt "600" ]]; then
					if [ "$InstallStatus" = "true" ]; then
						#echo $DateNow
						#echo $XMLUpdateFile
						#echo $DiffTimeOn
						echo "<-Start Result->"
						echo "CSMon_Result=File Protection process :Might not running"
						echo "<-End Result->"
						exit 1;
					fi;
				fi;

				#Last Complete > X days
				if [ $BackupLast ]; then
					let "DiffTime = DateNow - BackupLast"
					let "DiffDays = DiffTime / 86400"
				else
					DiffB=1;
				fi;
				if [[ "$BackupErrorDelay" -ne "0" && "$BackupErrorDelay" -ne "$Null" ]]; then
					BackWarn="Backup Warning: $BackupErrorDelay sec (server imposed backup delay for problem files) | "
					AgentOn="File Protection: Online | $LeftSize left to Backup | $FullSize Backup Delay: $BackupErrorDelay sec (server imposed backup delay for problem files) | "
					AlertShow=1
					MessageAlert="$MessageAlert $BackWarn"
				elif [ "$BackupActive" = "1" ]; then
					AgentOn="File Protection: Online | $LeftSize left to Backup | $FullSize Backup Remaining: $BackupRemaning sec | "
				elif [ "$RestoreActive" = "1" ]; then 
					AgentOn="File Protection: Restoring | $RestoreSize left to Restore | Restore Remaining: $RestoreRemaning | "
				elif [ "$AgentOnline" = "online" ]; then
					AgentOn="File Protection: Online | $FullSize"
				else
					if [ "$AgentOnline" = "$Null" ]; then
						AgentOn="File Protection: Online | $FullSize"
					else
						AgentOn="File Protection: $AgentOnline | $FullSize"
					fi;
				fi;
				
				if [ "$DiffB" = "0" ]; then
					if [[ "$backupDays" -le "$DiffDays" && "$LastComplete" == "true" && "$LeftBackup" -ne "0" ]]; then
						MessageAlertLast=1;
					fi;
					if [[ "$DiffDays" = "0" ]]; then
						LastC="Last completed: Today | "
					else
						LastC="Last completed: $DiffDays days | ";
					fi;
					if [[ "$MessageAlertLast" = "1" ]]; then
						AlertShow=1
						MessageAlert="$MessageAlert $LastC";
					fi;
				else
					LastC="Last completed: No backups | ";
					if [[ "$LastComplete" = "true" ]]; then
						AlertShow=1
						MessageAlert="$MessageAlert $LastC";
					fi;
				fi;
				if [ "$AlertShow" = "1" ]; then
					echo "<-Start Result->"
					echo "CSMon_Result=User[$user]::$MessageAlert"
					echo "<-End Result->"
					exit 1;		
				fi;
				# ###################################
			fi;
		fi;
	
	done	
	
	if [ "$hasProcess" = "0" ]; then		    
	
        echo "<-Start Result->"
        echo "CSMon_Result=File Protection process is not running"
        echo "<-End Result->"
        exit 1;
    fi;
fi