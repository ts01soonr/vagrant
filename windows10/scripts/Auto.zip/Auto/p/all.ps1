Write-Host "monitor scrpts: a|b|w.ps1 at"(Get-Date)
$inv = (Get-Variable MyInvocation).Value
$dir = Split-Path $inv.MyCommand.Path
Write-Host "--------AEB----------"
& $dir\a.ps1
Write-Host "--------BSA----------"
& $dir\b.ps1
Write-Host "--------AWP----------"
& $dir\w.ps1