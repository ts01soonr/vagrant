#AEB/S Monitor (Windows) Build 10

param (
    [string]$Customfield1,
    [string]$Customfield2,
    [Int32]$backupDays,
    [string]$InstallStatus,
    [string]$ServiceStatus,
    [string]$SubStatus,
    [string]$BackupWarning,
    [string]$LastComplete
)  

if ([Environment]::GetEnvironmentVariable("UDF1", "Process")) {
    $Customfield1 = [Environment]::GetEnvironmentVariable("UDF1", "Process")
}

if ([Environment]::GetEnvironmentVariable("UDF2", "Process")) {
    $Customfield2 = [Environment]::GetEnvironmentVariable("UDF2", "Process")
}

if ([Environment]::GetEnvironmentVariable("backupDays", "Process")) {
    $backupDays = [Environment]::GetEnvironmentVariable("backupDays", "Process")
}

#check the existence of folder "CentraStage"
if (!(Test-Path Registry::HKLM\SOFTWARE\CentraStage)) {
    New-Item Registry::HKLM\SOFTWARE\CentraStage
}

if ([Environment]::GetEnvironmentVariable("InstallStatus", "Process")) {
    $InstallStatus = [Environment]::GetEnvironmentVariable("InstallStatus", "Process")
}

if ([Environment]::GetEnvironmentVariable("ServiceStatus", "Process")) {
    $ServiceStatus = [Environment]::GetEnvironmentVariable("ServiceStatus", "Process")
}

if ([Environment]::GetEnvironmentVariable("SubStatus", "Process")) {
    $SubStatus = [Environment]::GetEnvironmentVariable("SubStatus", "Process")
}

if ([Environment]::GetEnvironmentVariable("BackupWarning", "Process")) {
    $BackupWarning = [Environment]::GetEnvironmentVariable("BackupWarning", "Process")
}

if ([Environment]::GetEnvironmentVariable("LastComplete", "Process")) {
    $LastComplete = [Environment]::GetEnvironmentVariable("LastComplete", "Process")
}

function Write-CustomField {
    param([string]$Value,
          [string]$Field
    )
    
    Set-ItemProperty -Path HKLM:\SOFTWARE\CentraStage -Name $Field -Value $Value
}

function Write-Alert {
    param([string]$Alert)
    Write-Host "<-Start Result->"
    Write-Host "CSMon_Result="$Alert
    Write-Host "<-End Result->"
    exit 1
}

function get-epochDate ($epochDate) { 
    [timezone]::CurrentTimeZone.ToLocalTime(([datetime]'1/1/1970').AddSeconds($epochDate)) 
}

function get-size ($S) { 
    if ($S -eq 0) { return '0 Bytes'}
    if ($S -lt 1024*1024){ return $("{0:N2}" -f ($S/1KB)) +' KB'  }
    if ($S -lt 1024*1024*1024){ return $("{0:N2}" -f ($S/1MB)) +' MB'  }
    return $("{0:N2}" -f ($S/1GB)) +' GB'
       
}

$bool = 0
$DiffB = 0
$AlertShow = 0
$MessageAlertLast = 0
$AEBService = 0

$MessageAlert = ''
$StatInst = ''
$AgentOn = ''
$Subscr = ''
$BackWarn = ''
$UpdReq = ''
$LastC = ''
$UsPr = ''

$bits_OS = (Get-WmiObject Win32_OperatingSystem).OSArchitecture.Substring(0,2)

#Check whether the program is installed
$search_inst = Get-ChildItem -Path Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall
$search_inst | % {
    if ($(get-itemproperty -Path Registry::$($_)).DisplayName -match 'Autotask Endpoint Backup Server') {
        $bool = 1
    }
}

[xml] $RawData = $RawData.Clear

#### check $AEBService First similar to AEB
$(Get-Service) | % {
    if ($_.DisplayName -match 'Autotask Endpoint Backup Server Service') {
        $AEBService = 1
    }
}
if ($AEBService -eq 1) {
	if ((Get-Service -DisplayName "Autotask Endpoint Backup Server Service").Status -ne 'Running') {
		Write-Host $("AEB/S service is not running")
		Write-Alert "AEB/S service is not running" 
	}
}
### 

if ($bool -eq 1) {

    if ($bits_OS -eq 32) {
        $IstallTypeCat = $(Get-ItemProperty -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Autotask Corporation\Endpoint Backup Server\' -Name InstallType).InstallType
    } elseif ($bits_OS -eq 64) {
        $IstallTypeCat = $(Get-ItemProperty -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Autotask Corporation\Endpoint Backup Server\' -Name InstallType).InstallType
    }
    $XmlPath = $Env:ProgramData +'\Autotask Corporation\Common\Status Report - Autotask Endpoint Backup Server.xml'
    if( $IstallTypeCat -ne 'live'){
            $XmlPath = $Env:ProgramData +'\Autotask Corporation\Common\Status Report - Autotask Endpoint Backup Server('+$IstallTypeCat+').xml'
    }
	if ( -Not (Test-Path $XmlPath )) { Write-Alert "AEB/S has not yet been configured" }
	
	[xml]$RawData = get-content $XmlPath
	
    $RawData.'status-report'.value | % {
        #service status
        if ($_.name -match 'agent-online') {
            $AgentOnline = $_.'#text'
            if ($ServiceStatus -match 'true' -and $AgentOnline -eq 'disconnected') {
                $AlertShow = 1
                $MessageAlert += 'AEB: ' + $AgentOnline + ' | '
            }
        }
        ###Subscription status (disabled in logfile)
        if ($_.name -match 'agent-subscription-status') {
            if ($SubStatus -match 'true') {
                $Subscr = 'Subscription status: ' + $_.'#text' + ' | '
                if (!($_.'#text' -eq 'enabled')) {
                    $AlertShow = 1
                    $MessageAlert += $Subscr
                }
            } else {
                $Subscr = ''
            }
        }
        ###Backup Warning   BackupWarning
        if ($_.name -eq 'backup-warning') {
            $BackupWarn = $_.'#text'
            if ($BackupWarning -match 'true') {
                if ($_.'#text' -eq $Null) {
                    $BackWarn = 'Backup Warning: No warning | '
                } else {
                    $BackWarn = 'Backup Warning: ' + $_.'#text' + ' | '
                    $AlertShow = 1
                    $MessageAlert += $BackWarn
                }
            } else {
                $BackWarn = ''
            }
        }
        #Last Complete Backup
        if ($_.name -match 'backup-last-complete') {
            $BackupLast = $_.'#text'
        }
        #XX MB left to Backup
        if ($_.name -match 'backup-bytes-remaining') {
            $stringA = ''
            $LeftToBackup = $_.'#text'
            $LeftToBackup.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
            $LeftBackup = [int64]$stringA
        }
        #Backup Size
        if ($_.name -match 'backup-numbytes') {
            $Size = $_.'#text'
            $stringA = ''
            $Size.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
            $BackupSize = [int64]$stringA
			$FullSize = 'Backup Size: '+ $(get-size $BackupSize) + ' | '
        }
        #Backup Remaning (sec)
        if ($_.name -match 'backup-timeleft') {
            $BackupRemaning = $_.'#text'
        }
        #Restore Size
        if ($_.name -match 'restore-bytes') {
            $RestoreSize = $_.'#text'
        }
        #Restore Remaning (sec)
        if ($_.name -match 'restore-time') {
            $RestoreRemaning = $_.'#text'
        }
        #Backup active?
        if ($_.name -match 'backup-active') {
            $BackupActive = $_.'#text'
        }
        #Restore active?
        if ($_.name -match 'restore-active') {
            $RestoreActive = $_.'#text'
        }
        #server imposed backup delay (for problem files) in seconds
        if ($_.name -match 'backup-error-delay') {
            $BackupErrorDelay = $_.'#text'
        }
        ###
        if ($InstallStatus -match 'true') {
            if ($_.name -match 'setup-deployment-status') {
                $StatInst = 'Installation Status: ' + $_.'#text' + ' | '
                if (!($_.'#text' -eq 'finished')) {
                    $AlertShow = 1
                    $MessageAlert += $StatInst
                }
            }
        } else {
            $StatInst = ''
        }
        #AEB Version
        if ($_.name -match 'agent-version') {
            $AEB_Version = $_.'#text'+'-'+ $IstallTypeCat
        }
            
    }
    #AEB Agent ID
    $AEBAgentID = $RawData.'status-report'.rcid
    if ($AEBAgentID -eq '') {
        $AEBAgentID = 'Undefined'
    }
    Write-Host $('AEB/S Version: ' + $AEB_Version + ' | AEB/S Agent ID: ' + $AEBAgentID + ' | ')
        
    #status-report tag now
    $stringA = ''
    $TempXMLUpdateFile = $RawData.'status-report'.now
    $TempXMLUpdateFile.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
    $XMLUpdateFile = [int64]$stringA
    $DateNow = Get-Date

   
    if ($($DateNow.ToUniversalTime()-$(get-epochDate $XMLUpdateFile).ToUniversalTime()).TotalMinutes -gt 10) {
        Write-Host $("AEB/S: Not running")
        Write-Alert "AEB/S: Not running"
    }
        
    #Last Complete > X days
    $stringA = ''
    if (!($BackupLast -eq $Null)) {
        $BackupLast.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
        $updateINT = [int]$stringA
        $DiffTime = $DateNow.ToUniversalTime() - $(get-epochDate $updateINT).ToUniversalTime()
        $DiffDays = $DiffTime.Days
    } else {
        $DiffB = 1
    }
    if ($BackupErrorDelay -ne '0' -and $BackupErrorDelay -ne $Null) {
        $BackWarn = 'Backup Warning: ' + $BackupErrorDelay + ' sec (server imposed backup delay (for problem files)  | '
        $AgentOn = 'AEB/S: Online | ' + $(get-size $LeftBackup) + ' left to Backup | ' + $FullSize + 'Backup Delay: ' + $BackupErrorDelay + ' sec (server imposed backup delay (for problem files)  | '
        $AlertShow = 1
        $MessageAlert += $BackWarn
    } elseif ($BackupActive -match '1') {
        $AgentOn = 'AEB/S: Online | ' + $(get-size $LeftBackup) + ' left to Backup | ' + $FullSize + 'Backup Remaining: ' + $BackupRemaning + ' sec | '
    } elseif ($RestoreActive -match '1') {
        $AgentOn = 'AEB/S: Restoring | ' + $(get-size $RestoreSize) + ' left to Restore | Restore Remaining: ' + $RestoreRemaning + ' | '
    } elseif ($AgentOnline -match 'online') {
        $AgentOn = 'AEB/S: Online | ' + $FullSize
    } else {
        if ($AgentOnline -eq $Null) {
            $AgentOn = 'AEB/S: ? | ' + $FullSize
        } else {
            $AgentOn = 'AEB/S: ' + $AgentOnline + ' | ' + $FullSize
        }
    }
    if ($DiffB -eq 0) {
        if ($backupDays -le $DiffDays -and $LastComplete -match 'true') {
            $MessageAlertLast = 1
        }
        if ($DiffDays -eq 0) {
            $LastC = 'Last completed: Today | '
        } else {
            $LastC = 'Last completed: ' + $DiffDays.ToString() + ' days | '
        }
        if ($MessageAlertLast -eq 1) {
            $MessageAlert += $LastC
        }
    } else {
        $LastC = 'Last completed: Unknown | '
        if ($LastComplete -match 'true') {
            $AlertShow = 1
            $MessageAlert += $LastC
        }
    }
    if ($AlertShow -eq 1 -or $MessageAlertLast -eq 1) {
        Write-Host $($AgentOn + $LastC)
        Write-Alert $MessageAlert
    } else {
        Write-Host $($AgentOn + $LastC)
    }
} else { 
    Write-Host $("AEB/S is not installed")
    Write-Host $("...")
	Write-Alert "AEB/S is not installed"	
}
