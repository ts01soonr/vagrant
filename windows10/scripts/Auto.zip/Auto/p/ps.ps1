# Datto File Protection UNIFIED monitor :: build 22/seagull :: thanks to fang

<# --- USER VARIABLES ---
usrUDF1                   first of two UDF nominations into which the data from enabled criteria will be shown
usrUDF2                   second of two UDF nominations into which the data from enabled criteria will be shown
usrDaysToCheck            check to ensure a backup took place within this many days of checking interval
usrShowInstallStatus      show the 'install status' criterion
usrShowServiceStatus      show the 'service status' criterion
usrShowBackupWarnings     show warnings raised during the backup process
usrMonitorLastBackupDate  alert if the last backup was later than usrDaysToCheck
#>

# functions
function Write-CustomField {
    param([string]$Value,
          [string]$Field
    )
    
    Set-ItemProperty -Path HKLM:\SOFTWARE\CentraStage -Name $Field -Value $Value
}

function Write-Alert {
    param([string]$Alert)
    Write-Host "<-Start Result->"
    Write-Host "DattoProtect="$Alert
    Write-Host "<-End Result->"
    exit 1
}

function get-epochDate ($epochDate) { 
    [timezone]::CurrentTimeZone.ToLocalTime(([datetime]'1/1/1970').AddSeconds($epochDate)) 
}

function get-size ($S) { 
    if ($S -eq 0) { return '0 Bytes'}
    if ($S -lt 1024*1024){ return $("{0:N2}" -f ($S/1KB)) +' KB'  }
    if ($S -lt 1024*1024*1024){ return $("{0:N2}" -f ($S/1MB)) +' MB'  }
    return $("{0:N2}" -f ($S/1GB)) +' GB'   
}

# identification
# -- calculate registry node location based on interpreter architecture check
if ([intptr]::size -eq 8) {
    $varRegNode="SOFTWARE\Wow6432Node"
} else {
    $varRegNode="SOFTWARE"
}

# -- registry search
try {
    $varDFPType=(Get-ItemProperty -Path "HKLM:\$varRegNode\Datto\File Protectionx" -Name InstallType -ErrorAction Stop).InstallType
    $varProductName="File Protection"
	$varProcess="FileProtection"
    $varSuccess++
} 
catch [System.Exception] {
    $varFailure++
}

try {
    $varDFPType=(Get-ItemProperty -Path "HKLM:\$varRegNode\Datto\File Protection Server" -Name InstallType -ErrorAction Stop).InstallType
    $varProductName="File Protection Server"
	$varProcess="FileProtectionServer"
    $varSuccess++
} 
catch [System.Exception] {
    $varFailure++
}

if ($varSuccess -ge 2) {
    #DFP AND DFP/S are installed! why?!
    Write-Host $("File Protection and Server version clash")
    Write-Host $("...")
    Write-Alert "Both File Protection and File Protection Server are installed. Please uninstall one as the two will clash."
}

if ($varFailure -ge 2) {
    #neither are installed
    Write-Host $("File Protection is not installed.")
    Write-Host $("...")
    Write-Alert "No Datto File Protection installation was detected on this device."
}
#set env variables
$env:usrDaysToCheck = 30
$env:usrShowInstallStatus = 'true'
$env:usrShowServiceStatus = 'true'
$env:usrShowBackupWarnings = 'true'
$env:usrMonitorLastBackupDate = 'true'

# variables
$DiffB = 0
$AlertShow = 0
$MessageAlertLast = 0
$MessageAlert = ''
$StatInst = ''
$AgentOn = ''
$Subscr = ''
$BackWarn = ''
$UpdReq = ''
$LastC = ''
$UsPr = ''
$XmlPath = ''

$varDFPVersion=(Get-ChildItem -Path "HKLM:\$varRegNode\Microsoft\Windows\CurrentVersion\Uninstall" -ErrorAction SilentlyContinue | Get-ItemProperty | Where-Object -FilterScript {$_.DisplayName -match "Datto $varProductName"} | select-object "DisplayVersion" -first 1).DisplayVersion
if (!$varDFPVersion) {
    #DFP wasn't detected; throw execution
    Write-Host $("$varProductName was not detected")
    Write-Host $("...")
    Write-Alert "$varProductName was not detected on this system."
}

#if program is not in service mode, check to see if it's running :: if no user is logged in, quit
if (!(get-service -Displayname "Datto $varProductName Service*" -erroraction silentlycontinue)) {
    if (Get-Process explorer -ErrorAction SilentlyContinue) {
        if (!(Get-Process $varProcess -ErrorAction SilentlyContinue)) {
            Write-Host $("$varProductName process is not running")
            Write-Host $("...")
            Write-Alert "The $varProductName process is not running."
        }
    } else {
        Write-Host $("$varProductName process is not running (No users are logged in)")
        exit # quit without any further work
    }
} else {
    #product is in service mode, is it running
    if ($(Get-Service -DisplayName "Datto $varProductName Service*").Status -eq 'Stopped') {
        Write-Host $("-Service Mode- Service: Stopped")
        Write-Alert "$varProductName is in Service Mode but the service has been stopped."
    }
}

#get the logged-in user :: dec 2019
$varUsername=(Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Authentication\LogonUI" -Name LastLoggedOnSAMUser -ErrorAction Stop).LastLoggedOnSAMUser
if ($varUsername -match '@') {
    #do nothing, we're good
} else {
    $varUsername=($varUsername -split '\',-1,'SimpleMatch')[1]
}

#ensure we factor in domain users :: jan 2020
ForEach ($iteration in (Get-ChildItem "$env:PUBLIC\..\" -Filter "$varUsername*" | where { $_.psiscontainer } | % { $_.fullname })) {
    If (Test-Path ("$iteration\AppData\Local\Datto\Common\Status Report - Datto $varProductName*.xml")) {
        $varPathInst = "$iteration\AppData\Local\Datto\Common\"
    }
}

if ($varProcess -eq 'FileProtectionServer') { $varPathInst="$env:PROGRAMDATA\Datto\Common\" }
$varAgentType=$(Get-ItemProperty -Path "HKLM:\$varRegNode\Datto\$varProductName" -Name InstallType).InstallType   
#get the 'type' of 'agent'-- either 'live' or internal    
if ($varAgentType -eq 'live') {       
    $XmlPath = $($varPathInst + "Status Report - Datto $varProductName.xml")
} else {
    $XmlPath =  $($varPathInst + $("Status Report - Datto $varProductName($varAgentType).xml"))
} 

if ( -Not (Test-Path $XmlPath )) { Write-Alert "$varProductName has not yet been set up." }	


[xml]$RawData = get-content $XmlPath
$RawData.'status-report'.value | % {
    #service status
    if ($_.name -match 'agent-online') {
        $AgentOnline = $_.'#text'
        if ($env:usrShowServiceStatus -match 'true' -and $AgentOnline -eq 'disconnected') {
            $AlertShow = 1
            $MessageAlert += "$varProductName`: " + $AgentOnline + ' | '
        }
    }

    ###Backup Warning   BackupWarning
    if ($_.name -eq 'backup-warning') {
        $BackupWarn = $_.'#text'
        if ($env:usrShowBackupWarnings -match 'true') {
            if ($_.'#text' -eq $Null) {
                $BackWarn = 'Backup Warning: No warning | '
            } else {
                $BackWarn = 'Backup Warning: ' + $_.'#text' + ' | '
                $AlertShow = 1
                $MessageAlert += $BackWarn
            }
        } else {
            $BackWarn = ''
        }
    }
    #Last Complete Backup
    if ($_.name -match 'backup-last-complete') {
        $BackupLast = $_.'#text'
    }
    #XX MB left to Backup
    if ($_.name -match 'backup-bytes-remaining') {
        $stringA = ''
        $LeftToBackup = $_.'#text'
        $LeftToBackup.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
        $LeftBackup = [int64]$stringA
    }
    #Backup Size
    if ($_.name -match 'backup-numbytes') {
        $Size = $_.'#text'
        $stringA = ''
        $Size.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
        $BackupSize = [int64]$stringA
        $FullSize = 'Backup Size: '+ $(get-size $BackupSize) + ' | '
    }
    #Backup Remaning (sec)
    if ($_.name -match 'backup-timeleft') {
        $BackupRemaning = $_.'#text'
    }
    #Restore Size
    if ($_.name -match 'restore-bytes') {
        $RestoreSize = $_.'#text'
    }
    #Restore Remaning (sec)
    if ($_.name -match 'restore-time') {
        $RestoreRemaning = $_.'#text'
    }
    #Backup active?
    if ($_.name -match 'backup-active') {
        $BackupActive = $_.'#text'
    }
    #Restore active?
    if ($_.name -match 'restore-active') {
        $RestoreActive = $_.'#text'
    }
    #server imposed backup delay (for problem files) in seconds
    if ($_.name -match 'backup-error-delay') {
        $BackupErrorDelay = $_.'#text'
    }
    ###
    if ($env:usrShowInstallStatus -match 'true') {
        if ($_.name -match 'setup-deployment-status') {
            $StatInst = 'Installation Status: ' + $_.'#text' + ' | '

            if ($_.'#text' -eq 'wait-admin') {
                 $StatInst = 'Installation Status: Waiting for Administrator approval'
                 $AgentOnline = 'Waiting for Administrator approval'
            }

            if (!($_.'#text' -eq 'finished')) {
                $AlertShow = 1
                $MessageAlert += $StatInst
            }
        }
    } else {
        $StatInst = ''
    }
            
}
#DFA Agent ID
$AEBAgentID = $RawData.'status-report'.rcid
if ($AEBAgentID -eq '') {
    $AEBAgentID = 'Undefined'
}
Write-Host $("$varProductName Version: " + $varDFPVersion + ' | Agent ID: ' + $AEBAgentID + ' | ')
        
#status-report tag now
$stringA = ''
$TempXMLUpdateFile = $RawData.'status-report'.now
$TempXMLUpdateFile.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
$XMLUpdateFile = [int64]$stringA
$DateNow = Get-Date

if ($($DateNow.ToUniversalTime()-$(get-epochDate $XMLUpdateFile).ToUniversalTime()).TotalMinutes -gt 6) {
    Write-Host $("$varProductName`: Not running")
    Write-Alert "Datto $varProductName is not running."
}
        
#Last Complete > X days
$stringA = ''
#if the XML data saying the last time a backup was taken isn't "nothing"...
if (!($BackupLast -eq $Null)) {
    $BackupLast.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
    $updateINT = [int]$stringA
    $DiffTime = $DateNow.ToUniversalTime() - $(get-epochDate $updateINT).ToUniversalTime()
    $DiffDays = $DiffTime.Days
} else {
    $DiffB = 1
}
if ($BackupErrorDelay -ne '0' -and $BackupErrorDelay -ne $Null) {
    $BackWarn = 'Backup Warning: ' + $BackupErrorDelay + ' sec (server-imposed backup delay for problem files)  | '
    $AgentOn = "$varProductName`: Online | " + $(get-size $LeftBackup) + ' left to Backup | ' + $FullSize + 'Backup Delay: ' + $BackupErrorDelay + ' sec (server imposed backup delay (for problem files)  | '
    $AlertShow = 1
    $MessageAlert += $BackWarn
} elseif ($BackupActive -match '1') {
    $AgentOn = "$varProductName`: Online | " + $(get-size $LeftBackup) + ' left to Backup | ' + $FullSize + 'Backup Remaining: ' + $BackupRemaning + ' sec | '
} elseif ($RestoreActive -match '1') {
    $AgentOn = "$varProductName`: Restoring | " + $RestoreSize + ' left to Restore | Restore Remaining: ' + $RestoreRemaning + ' | '
} elseif ($AgentOnline -match 'online') {
    $AgentOn = "$varProductName`: Online | " + $FullSize
} else {
    if ($AgentOnline -eq $Null) {
        $AgentOn = "$varProductName`: Unknown | " + $FullSize
    } else {
        $AgentOn = "$varProductName`: " + $AgentOnline + ' | ' + $FullSize
    }
}
if ($DiffB -eq 0) {
    if ($env:usrDaysToCheck -le $DiffDays -and $env:usrMonitorLastBackupDate -match 'true') {
        $MessageAlertLast = 1
    }
    if ($DiffDays -eq 0) {
        $LastC = 'Last completed: Today | '
    } else {
        $LastC = 'Last completed: ' + $DiffDays.ToString() + ' days | '
    }
    if ($MessageAlertLast -eq 1) {
        $MessageAlert += $LastC
    }
} else {
    $LastC = 'Last completed: Unknown | '
    if ($env:usrMonitorLastBackupDate -match 'true') {
        $AlertShow = 1
        $MessageAlert += $LastC
    }
}
if ($AlertShow -eq 1 -or $MessageAlertLast -eq 1) {
    Write-Host $($AgentOn + $LastC)
    Write-Alert $MessageAlert
} else {
    Write-Host $($AgentOn + $LastC)
}
