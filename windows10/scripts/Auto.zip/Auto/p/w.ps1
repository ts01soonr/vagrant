#AWP Monitor build 32/SEAGULL

param (
    [string]$Customfield1="Custom4",
    [string]$Customfield2="Custom5",
    [Int32]$backupDays,
    [string]$InstallStatus,
    [string]$ServiceStatus
)  

$ErrorActionPreference = "stop"

if (([IntPtr]::size) -eq 4) {$varSoftware='SOFTWARE'} else {$varSoftware='SOFTWARE\WOW6432Node'}

if ([Environment]::GetEnvironmentVariable("UDF1", "Process")) {
    $Customfield1 = [Environment]::GetEnvironmentVariable("UDF1", "Process")
}

if ([Environment]::GetEnvironmentVariable("UDF2", "Process")) {
    $Customfield2 = [Environment]::GetEnvironmentVariable("UDF2", "Process")
}

if ([Environment]::GetEnvironmentVariable("backupDays", "Process")) {
    $backupDays = [Environment]::GetEnvironmentVariable("backupDays", "Process")
}

#check the existence of folder "CentraStage"
if (!(Test-Path Registry::HKLM\SOFTWARE\CentraStage)) {
    New-Item Registry::HKLM\SOFTWARE\CentraStage
}

if ([Environment]::GetEnvironmentVariable("InstallStatus", "Process")) {
    $InstallStatus = [Environment]::GetEnvironmentVariable("InstallStatus", "Process")
}

if ([Environment]::GetEnvironmentVariable("ServiceStatus", "Process")) {
    $ServiceStatus = [Environment]::GetEnvironmentVariable("ServiceStatus", "Process")
}

function Write-CustomField {
    param([string]$Value,
          [string]$Field
    )
    
    Set-ItemProperty -Path HKLM:\SOFTWARE\CentraStage -Name $Field -Value $Value
}

function Write-Alert {
    param([string]$Alert)
    Write-Host "<-Start Result->"
    Write-Host "CSMon_Result="$Alert
    Write-Host "<-End Result->"
    exit 1
}

function get-epochDate ($epochDate) { 
    [timezone]::CurrentTimeZone.ToLocalTime(([datetime]'1/1/1970').AddSeconds($epochDate)) 
}

function get-size ($S) { 
    if ($S -eq 0) { return '0 Bytes'}
    if ($S -lt 1024*1024){ return $("{0:N2}" -f ($S/1KB)) +' KB'  }
    if ($S -lt 1024*1024*1024){ return $("{0:N2}" -f ($S/1MB)) +' MB'  }
    return $("{0:N2}" -f ($S/1GB)) +' GB'
       
}

$bool = 1
$DiffB = 0
$AlertShow = 0
$MessageAlertLast = 0
$AWPService = 0

$MessageAlert = ''
$StatInst = ''
$AgentOn = ''
$Subscr = ''
$BackWarn = ''
$UpdReq = ''
$LastC = ''
$UsPr = ''
$XmlPath = ''

#Check whether the program is installed
try {$varAWPPID=(get-itemproperty -Path Registry::"HKEY_LOCAL_MACHINE\$varSoftware\Autotask Corporation\Workplace" -Name ProductCode).ProductCode}
catch [System.Exception] {
    $bool = 0
}

#NEW: Check whether the program is of the correct version + robust retry when exception happens 
if ($bool -eq 1) {
    try {$installPath=(get-itemproperty -Path Registry::"HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall\$varAWPPID" -Name InstallLocation).InstallLocation}
    catch [System.Exception] {
		### another try
        if (([IntPtr]::size) -eq 4) { $installPath = ${env:ProgramFiles} } else { $installPath = ${env:ProgramFiles(x86) } } 
        $installPath = $installPath+"\Autotask Corporation\Workplace"
        if(Test-Path $installPath\AutotaskWorkplace.exe) { $bool = 1} else { $bool = 0 }    
    }
}

if ($bool -eq 1) {

	[string]$AWPVersion=(dir $installPath AutotaskWorkplace.exe) | %{ $_.VersionInfo }
    if ($AWPVersion.split(".")[0] -lt 7) {
        Write-Host $("Please update AWP Agent to v7 or higher")
        Write-Alert "AWP Agent needs to be at least version 7 to use monitor - please update"
    }
    
	[xml] $RawData = $RawData.Clear

    $(Get-Service) | % {
        if ($_.DisplayName -match 'Autotask Workplace Volume Shadow Copy*') {
            $AWPService = 1
        }
    }

    if (!(Get-Process AutotaskWorkplace -ErrorAction SilentlyContinue)) {
        Write-Host $("AWP process is not running")
        Write-Alert "AWP process is not running"
    }

	
	Get-WMIObject Win32_Process|?{$_.name -match 'AutotaskWorkplace.exe'}| % { 
	$Usersid = $_.getownersid().Sid
	}
	$ProfileLookup = 'HKEY_USERS\' + $Usersid + '\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders'
	[string]$UserPr=(Get-ItemProperty -Path Registry::$ProfileLookup -Name 'Local AppData')
	$UserPr = $UserPr.split('\')[2]
     
    #XML re-code because AWP always uses the same filename 
    $PathInst = $($env:USERPROFILE).Split(":")[0] + ':\Users\' + $UserPr + '\AppData\Local\Autotask Corporation\Common\'
		
	$IstallTypeCat=$(Get-ItemProperty -Path Registry::$('HKEY_LOCAL_MACHINE\'+$varSoftware+'\Autotask Corporation\Workplace\') -Name InstallType).InstallType	
	if( $IstallTypeCat -ne 'live'){
            $XmlPath = $PathInst + 'Status Report - Autotask Workplace Desktop('+$IstallTypeCat+').xml'
    }else{
			$XmlPath = $PathInst + 'Status Report - Autotask Workplace Desktop.xml'
	}	
	if ( -Not (Test-Path $XmlPath )) { Write-Alert "AWP is not setup yet" }
	
    [xml] $RawData = get-content $XmlPath

    $RawData.'status-report'.value | % {
        #service status
        if ($_.name -match 'agent-online') {
            $AgentOnline = $_.'#text'
            if ($ServiceStatus -match 'true' -and $AgentOnline -eq 'disconnected') {
                $AlertShow = 1
                $MessageAlert += $AgentOnline
            }
        }

        ###Hardware approval
        if ($_.name -eq 'agent-hw-approved') {
            $BackupWarn = $_.'#text'
            if ($_.'#text' -eq 1) {
                # do nothing
            } else {
            Write-Host $("Agent Hardware not Approved")
            Write-Alert "Agent Hardware not Approved"
            }
        }

        ###Sync MPF Status
        if ($_.name -eq 'sync-mpf-status') {
            $BackupWarn = $_.'#text'
            #"ENGINE_OK" WHEN WE WERE PRESENTED WITH AN INT IN THE DOCUMENTATION
            if ($BackupWarn -like '0' -or $BackupWarn -like '2' -or $BackupWarn -like 'engine_ok') {
                $BackWarn = 'Sync Status: OK'
            } else {
                $SyncError=$true
                $SyncWarn = 'Sync Error ' + $BackupWarn            
                Write-Host "<-Start Result->"
                Write-Host "CSMon_Result=Sync failed`: Sync MPF Error $BackupWarn"
                Write-Host "<-End Result->"
            }
        }
        ###Backup Warning   BackupWarning
        if ($_.name -eq 'backup-warning') {
            $BackupWarn = $_.'#text'
                if ($_.'#text' -eq $Null) {
                # do nothing
                } else {
                    $BackWarn = 'Backup Warning: ' + $_.'#text'
                    $AlertShow = 1
                    $MessageAlert += $BackWarn
                }
        }

        #Last Complete Backup
        if ($_.name -match 'backup-last-complete') {
            $BackupLast = $_.'#text'
        }
        #XX MB left to Backup
        if ($_.name -match 'backup-bytes-remaining') {
            $stringA = ''
            $LeftToBackup = $_.'#text'
            $LeftToBackup.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
            $LeftBackup = [int64]$stringA
        }
        #Backup Size
        if ($_.name -match 'backup-numbytes') {
            $Size = $_.'#text'
            $stringA = ''
            $Size.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
            $BackupSize = [int64]$stringA
            $FullSize = 'Backup Size: '+ $(get-size $BackupSize) + ' | '
        }
        #Backup Remaning (sec)
        if ($_.name -match 'backup-timeleft') {
            $BackupRemaning = $_.'#text'
        }
        #Restore Size
        if ($_.name -match 'restore-bytes') {
            $RestoreSize = $_.'#text'
        }
        #Restore Remaning (sec)
        if ($_.name -match 'restore-time') {
            $RestoreRemaning = $_.'#text'
        }
        #Backup active?
        if ($_.name -match 'backup-active') {
            $BackupActive = $_.'#text'
        }
        #Restore active?
        if ($_.name -match 'restore-active') {
            $RestoreActive = $_.'#text'
        }
        #server imposed backup delay (for problem files) in seconds
        if ($_.name -match 'backup-error-delay') {
            $BackupErrorDelay = $_.'#text'
        }
        ###
        if ($InstallStatus -match 'true') {
            if ($_.name -match 'setup-deployment-status') {
                $StatInst = 'Installation Status: ' + $_.'#text' + ' | '
                if (!($_.'#text' -eq 'finished')) {
                    $AlertShow = 1
                    $MessageAlert += $StatInst
                }
            }
        } else {
            $StatInst = ''
        }
        #AWP Version
        if ($_.name -match 'agent-version') {
            $AWP_Version = $_.'#text'+'-'+ $IstallTypeCat
        }
            
    }
    #AWP Agent ID
    $AWPAgentID = $RawData.'status-report'.rcid
    if ($AWPAgentID -eq '') {
        $AWPAgentID = 'Undefined'
    }

    if ($SyncError) {$BackWarn = $SyncWarn}

    #write AWP Status field
    Write-Host $('AWP Version: ' + $AWP_Version + ' | AWP Agent ID: ' + $AWPAgentID + ' | ' + $BackWarn + ' [User: ' + $UserPr + ']')
        
    #status-report tag now
    $stringA = ''
    $TempXMLUpdateFile = $RawData.'status-report'.now
    $TempXMLUpdateFile.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
    $XMLUpdateFile = [int64]$stringA
    $DateNow = Get-Date
    
    if ($($DateNow.ToUniversalTime()-$(get-epochDate $XMLUpdateFile).ToUniversalTime()).TotalMinutes -gt 10) {
        Write-Host $("AWP: Not running")
        Write-Alert "AWP: Not running"
    }
        
    #Last Complete > X days
    $stringA = ''
    if (!($BackupLast -eq $Null)) {
        $BackupLast.GetEnumerator() | % { if ( $_ -match "[0-9]" ) { $stringA += $_ }  }
        $updateINT = [int]$stringA
        $DiffTime = $DateNow.ToUniversalTime() - $(get-epochDate $updateINT).ToUniversalTime()
        $DiffDays = $DiffTime.Days
    } else {
        $DiffB = 1
    }
    if ($BackupErrorDelay -ne '0' -and $BackupErrorDelay -ne $Null) {
        $BackWarn = 'Backup Warning: ' + $BackupErrorDelay + ' sec (server imposed backup delay (for problem files)  | '
        $AgentOn = 'AWP: Online | ' + $(get-size $LeftBackup) + ' left to Backup | ' + $FullSize + 'Backup Delay: ' + $BackupErrorDelay + ' sec (server imposed backup delay for problem files)  | '
        $AlertShow = 1
        $MessageAlert += $BackWarn
    } elseif ($BackupActive -match '1') {
        $AgentOn = 'AWP: Online | ' + $(get-size $LeftBackup) + ' left to Backup | ' + $FullSize + 'Backup Remaining: ' + $BackupRemaning + ' sec | '
    } elseif ($RestoreActive -match '1') {
        $AgentOn = 'AWP: Restoring | ' + $(get-size $RestoreSize) + ' left to Restore | Restore Remaining: ' + $RestoreRemaning + ' | '
    } elseif ($AgentOnline -match 'online') {
        $AgentOn = 'AWP: Online | ' + $FullSize
    } else {
        if ($AgentOnline -eq $Null) {
            $AgentOn = 'AWP: ? | ' + $FullSize
        } else {
            $AgentOn = 'AWP: ' + $AgentOnline + ' | ' + $FullSize
        }
    }
    if ($DiffB -eq 0) {
        if ($DiffDays -eq 0) {
            $LastC = 'Last completed: Today | '
        } else {
            $LastC = 'Last completed: ' + $DiffDays.ToString() + ' days | '
        }
        if ($MessageAlertLast -eq 1) {
            $MessageAlert += $LastC
        }
    } else {
        $LastC = 'Last completed: Unknown | '
    }
    if ($AlertShow -eq 1 -or $MessageAlertLast -eq 1) {
        Write-Host $($AgentOn + $LastC)
        Write-Alert $MessageAlert
    } else {
        Write-Host $($AgentOn + $LastC)
    }
    if ($SyncError) {exit 1}
} else { 
    Write-Host $("AWP is not installed")
	Write-Host $("...")
    Write-Alert "AWP is not installed"	
}
