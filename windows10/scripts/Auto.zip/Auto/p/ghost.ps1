
# usage
# ghost.ps1 [d|c|s|p...] [check|remove]
# d-> dwp, 
# p-> dfp, 
# s-> dwpsa, 
# ps-> backup server agent
# c-> vfs cloud agent


$productType=$args[0]
$performAction=$args[1]

write-host "Product type: $productType"
write-host "Operation: $performAction"

if (( $productType -eq $null) -or ($productType -eq ""))
{
   Write-host "Product type is empty, can not continue"
   Write-host "Available options [d,p,s,ps,c]"
   Write-host "d -> DWP ,p -> DFP/BA,s -> DWPSA/FSA ,ps -> BSA, c -> DWC/VFS"
   Exit
}

if (( $performAction -eq $null) -or ($performAction -eq ""))
{
   Write-host "Perform action is empty, using Check as default -> available options [check,remove]"
   $performAction="check"
}

$productName = ""  # this should match the name in the registry

switch ($productType)
{    
    "p"  { $productName = "Datto\\File Protection\\"; Break}
    "ps" { $productName = "Datto\\File Protection Server\\"; Break}
    "d"  { $productName = "Datto\\Workplace Desktop\\"; Break}
    "s"  { $productName = "Datto\\Workplace Sever\\"; Break}   
	"c"  { $productName = "Datto\\Workplace2\\"; Break}
}


write-host "Checking for: $productName"

# installation path. Make sure that you don't mess with other components used 
# by any other MSI package

$components = Get-ChildItem -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Components\
$count = 0

foreach ($c in $components) 
{
    foreach($p in $c.Property)
    {
        $propValue = (Get-ItemProperty "Registry::$($c.Name)" -Name "$($p)")."$($p)"
        if ($propValue -match $productName) 
        {
            Write-Output $propValue
            $count++
            #For counting references just comment out
			if ($performAction -match "remove")
			{
                Write-Host "Removing"
				Remove-Item "Registry::$($c.Name)" -Recurse
			}
        }
    }
}

if ($performAction -match "remove")
{
    Write-Host "#$($count) key(s) removed"
}
else
{
    Write-Host "#$($count) key(s) exist"
}