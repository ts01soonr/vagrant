#!/bin/sh
launchctl unload /Library/LaunchDaemons/com.soonr.Fang.plist
sleep 3
launchctl load /Library/LaunchDaemons/com.soonr.Fang.plist
sleep 2